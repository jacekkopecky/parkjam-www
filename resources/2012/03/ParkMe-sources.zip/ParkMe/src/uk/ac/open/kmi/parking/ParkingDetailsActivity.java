package uk.ac.open.kmi.parking;

import uk.ac.open.kmi.parking.service.ParkingsService;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

/**
 * the activity that shows the details of a car park
 * @author Jacek Kopecky
 *
 */
public class ParkingDetailsActivity extends Activity {
    
    private View services;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.parking_details);
        
        Intent intent = this.getIntent();
        
        Uri parkingID = intent.getData();
        
        // todo set content
        TextView carparkName = (TextView) findViewById(R.id.details_currpark);
        carparkName.setText(parkingID.toString());
        
        TextView carparkDetails = (TextView) findViewById(R.id.details_description_text);
//        carparkDetails.setText("Note that the data you retrieve here should only be used as an optimization for handling configuration changes. You should always be able to handle getting a null pointer back, and an activity must still be able to restore itself to its previous state (through the normal onSaveInstanceState(Bundle) mechanism) even if this function returns null. Note that the data you retrieve here should only be used as an optimization for handling configuration changes. You should always be able to handle getting a null pointer back, and an activity must still be able to restore itself to its previous state (through the normal onSaveInstanceState(Bundle) mechanism) even if this function returns null. Note that the data you retrieve here should only be used as an optimization for handling configuration changes. You should always be able to handle getting a null pointer back, and an activity must still be able to restore itself to its previous state (through the normal onSaveInstanceState(Bundle) mechanism) even if this function returns null. Note that the data you retrieve here should only be used as an optimization for handling configuration changes. You should always be able to handle getting a null pointer back, and an activity must still be able to restore itself to its previous state (through the normal onSaveInstanceState(Bundle) mechanism) even if this function returns null. Note that the data you retrieve here should only be used as an optimization for handling configuration changes. You should always be able to handle getting a null pointer back, and an activity must still be able to restore itself to its previous state (through the normal onSaveInstanceState(Bundle) mechanism) even if this function returns null. Note that the data you retrieve here should only be used as an optimization for handling configuration changes. You should always be able to handle getting a null pointer back, and an activity must still be able to restore itself to its previous state (through the normal onSaveInstanceState(Bundle) mechanism) even if this function returns null.");
        
        // todo change to parkingsService.getParking or something
        Parking currParking = null;
        for (DrawableOverlayItem parking : ParkingsService.get().getCurrentItems(null)) {
            if (parking.id.equals(parkingID)) {
                currParking = (Parking)parking;
                break;
            }
        }
        
        // todo check that currParking is not null
        
//        new GeocoderAsyncTask(currParking.getPoint().getLatitudeE6()/1e6f, currParking.getPoint().getLongitudeE6()/1e6f, carparkDetails).execute();
        
        this.services = findViewById(R.id.details_services);
        this.services.setVisibility(View.GONE);
    }
    
/*    private static class GeocoderAsyncTask extends AsyncTask<Void, Void, List<Address>> {
        double lat;
        double lon;
        TextView carparkDetails;
        
        GeocoderAsyncTask(double lat, double lon, TextView carparkDetails) {
            this.lat = lat;
            this.lon = lon;
            this.carparkDetails = carparkDetails;
        }
        
        @Override
        protected List<Address> doInBackground(Void... none) {
            Geocoder geo = new Geocoder(ParkingDetailsActivity.this);
            try {
                return geo.getFromLocation(this.lat, this.lon, 1);
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return null;
        }
        
        @Override
        protected void onPostExecute(List<Address> addresses) {
            if (addresses == null)  {
                return;
            }
            StringBuilder sb = new StringBuilder(); // "have " + addresses.size() + "addresses:\n");
            for (Address addr : addresses) {
                sb.append("address: \n");
                sb.append(addr);
                sb.append("\n");
            }
            
            this.carparkDetails.setText(sb);
        }
    }*/

}
