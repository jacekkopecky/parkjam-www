package uk.ac.open.kmi.parking;

import android.graphics.drawable.Drawable;
import android.net.Uri;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.OverlayItem;

/**
 * an item in the parkme overlay class
 * @author Jacek Kopecky
 *
 */
public abstract class DrawableOverlayItem extends OverlayItem {

    /**
     * the RDF ID of the car park
     */
    public final Uri id;

    /**
     * constructor
     * @param point the location of the item
     * @param title the main name of the title
     * @param snippet further information to show in the overlay
     * @param id the identifier of the item
     */
    public DrawableOverlayItem(GeoPoint point, String title, String snippet, Uri id) {
        super(point, title, snippet);
        this.id = id;
    }

    /**
     * @return the drawable to be used for this item, should have the proper bounds
     */
    public abstract Drawable getDrawable();
    
    /**
     * comparator that sorts drawables north-to-south, west-to-east
     */
    public static class Comparator implements java.util.Comparator<DrawableOverlayItem> {

        public int compare(DrawableOverlayItem object1, DrawableOverlayItem object2) {
            if (object1 == null) {
                if (object2 == null) {
                    return 0;
                } else {
                    return -1;
                }
            } else if (object2 == null) {
                return 1;
            }
            GeoPoint p1 = object1.getPoint();
            GeoPoint p2 = object2.getPoint();
            if (p1.getLatitudeE6() > p2.getLatitudeE6()) {
                return -1;
            } else if (p1.getLatitudeE6() == p2.getLatitudeE6()) {
                if (p1.getLongitudeE6() > p2.getLongitudeE6()) {
                    return -1;
                } else if (p1.getLongitudeE6() == p2.getLongitudeE6()) {
                    int h1 = object1.hashCode();
                    int h2 = object2.hashCode();
                    return h1 < h2 ? -1 : (h1 == h2 ? 0 : 1);
                } else {
                    return 1;
                }
            } else {
                return 1;
            }
        }
    }
}
