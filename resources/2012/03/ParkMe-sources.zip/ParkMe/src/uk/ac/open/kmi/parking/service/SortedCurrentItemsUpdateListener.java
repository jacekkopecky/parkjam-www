package uk.ac.open.kmi.parking.service;

/**
 * not guaranteed to be called on the GUI thread
 * todo more docs
 * @author Jacek Kopecky
 *
 */
public interface SortedCurrentItemsUpdateListener {

    public void onSortedCurrentItemsUpdated();

}