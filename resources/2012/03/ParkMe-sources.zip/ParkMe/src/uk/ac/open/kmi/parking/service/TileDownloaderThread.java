package uk.ac.open.kmi.parking.service;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import uk.ac.open.kmi.parking.Parking;
import uk.ac.open.kmi.parking.Parking.Availability;
import android.net.Uri;
import android.util.Log;

import com.google.android.maps.GeoPoint;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.ResIterator;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.vocabulary.RDF;
import com.hp.hpl.jena.vocabulary.RDFS;

class TileDownloaderThread implements Runnable {
    private static final String TAG = "tile downloader";

    private final BlockingQueue<Event> eventQueue = new ArrayBlockingQueue<Event>(1000); // todo make this number configurable?
    private final Set<Event> eventPresenceSet = Collections.synchronizedSet(new HashSet<Event>(1000));

    private static final int SUPERTILE_FACTOR = 10;
    private static final int SUPERTILE_SIZE = ParkingsService.TILE_SIZE * SUPERTILE_FACTOR;

    // ten supertiles in the cache - up to four around the current location, six in browsing the map
    private final LRUCache<MapTile> cache = new LRUCache<MapTile>(10*SUPERTILE_FACTOR*SUPERTILE_FACTOR); 
    
    private int downloadCount = 0;
    private int maxQueueSize = 0;
    private long maxTimeToTake = 0;

    public void run() {
        for (;;) {
            try {
                int queueSize = this.eventQueue.size();
                if (queueSize > this.maxQueueSize) {
                    this.maxQueueSize = queueSize;
                    Log.i(TAG, "queue size maximum increased to " + this.maxQueueSize);
                    // todo check that this is sane over longer lives of the app, possibly lower the size of the queue
                    // todo do the same thing wherever I have an event queue
                }
                
                Event event = this.eventQueue.take();
                this.eventPresenceSet.remove(event);
                
                MapTile tile = event.tile;
                synchronized(this) {
                    if (this.cache.peek(tile)) {
    //                    Log.d(TAG, "tile already downloaded: " + tile);
                        continue;
                    }
                }
                long time = System.currentTimeMillis();
                long timeToTake = time - event.timeMillis;
                if (timeToTake > this.maxTimeToTake) {
                    this.maxTimeToTake = timeToTake;
                    Log.i(TAG, "queue maximum time to take up an event increased to " + this.maxTimeToTake + "ms");
                    // todo check that this is sane over longer lives of the app, possibly lower the size of the queue
                    // todo maybe do the same thing wherever I have an event queue with longer-running event handling
                }
                Log.d(TAG, "tile request " + tile + " taken up " + timeToTake + "ms after enqueued");

                synchronized(this) {
                    for (TileDesirabilityChecker checker : this.tileDesirabilityCheckers) {
                        if (checker.isTileDesirable(tile)) {
                            break; // tile desirable for at least one party, that'll do
                        }
                        Log.d(TAG, "tile no longer desirable: " + tile);
                    }
                }
                
                MapTile supertile = new MapTile();
                supertile.late6min = tile.late6min - (tile.late6min >= 0 ? tile.late6min % SUPERTILE_SIZE : (tile.late6min+1) % SUPERTILE_SIZE + SUPERTILE_SIZE-1); 
                supertile.lone6min = tile.lone6min - (tile.lone6min >= 0 ? tile.lone6min % SUPERTILE_SIZE : (tile.lone6min+1) % SUPERTILE_SIZE + SUPERTILE_SIZE-1); 
                
                Log.d(TAG, "tile " + tile + " makes supertile " + supertile);
                
                String uri = "http://parking.kmi.open.ac.uk/data/availetc?late6min=" + supertile.late6min + 
//                String uri = "http://137.108.25.60:8090/data/availetc?late6min=" + supertile.late6min + 
                        "&lone6min=" + supertile.lone6min + 
                        "&late6max=" + (supertile.late6min+SUPERTILE_SIZE) + 
                        "&lone6max=" + (supertile.lone6min+SUPERTILE_SIZE);
                InputStream is = FileManager.get().open(uri);
                if (is != null) {
                    Model model = ModelFactory.createDefaultModel();
                    model.read(is, uri, "TURTLE");
                    this.downloadCount++;

                    time = System.currentTimeMillis();
                    Log.d(TAG, "supertile " + this.downloadCount + " read " + (time - event.timeMillis) + "ms after request enqueued");
                    
                    MapTile[][] newtiles = new MapTile[SUPERTILE_FACTOR][SUPERTILE_FACTOR];
                    for (int i=0; i<SUPERTILE_FACTOR; i++) {
                        for (int j=0; j<SUPERTILE_FACTOR; j++) {
                            MapTile newtile = new MapTile();
                            newtile.late6min = supertile.late6min + i*ParkingsService.TILE_SIZE;
                            newtile.lone6min = supertile.lone6min + j*ParkingsService.TILE_SIZE;
                            newtile.parkings = new ArrayList<Parking>(200);
                            newtiles[i][j] = newtile;
//                            Log.v(TAG, "added new tile " + newtile);
                        }
                    }
                    
                    for (ResIterator parkings = model.listResourcesWithProperty(RDF.type, Onto.LGOParking); parkings.hasNext(); ) {
                        Resource parking = parkings.next();
                        double lat = Double.NaN;
                        double lon = Double.NaN;
                        Availability availability = Availability.UNKNOWN;
                        String title = null;
                        String id = parking.getURI();
                        for (StmtIterator stmts = model.listStatements(parking, null, (RDFNode)null); stmts.hasNext(); ) {
                            Statement s = stmts.next();
                            if (s.getPredicate().equals(Onto.GEOlat)) {
                                lat = s.getDouble();
                            } else if (s.getPredicate().equals(Onto.GEOlong)) {
                                lon = s.getDouble();
                            } else if (s.getPredicate().equals(RDFS.label)) {
                                title = s.getString();
                            } else if (s.getPredicate().equals(Onto.PARKINGavailable)) {
                                availability = s.getBoolean() ? Availability.AVAILABLE : Availability.FULL ;
                            } 
                        }
                        
                        if (lat==Double.NaN || lon==Double.NaN) {
                            Log.w(TAG, "parking " + id + " doesn't have all the properties (" + lat + ", " + lon + ")");
                            continue;
                        }
                        if (title == null) {
                            title = id.substring(id.lastIndexOf('/'));
                        }
                        int late6 = (int) Math.floor(lat*1e6);
                        int lone6 = (int) Math.floor(lon*1e6);
                        Parking newparking = new Parking(new GeoPoint(late6, lone6), title, Uri.parse(id), availability);
                        int i = (late6-supertile.late6min)/ParkingsService.TILE_SIZE;
                        int j = (lone6-supertile.lone6min)/ParkingsService.TILE_SIZE;
                        if (i<0 || i >=SUPERTILE_FACTOR || j<0 || j >= SUPERTILE_FACTOR) {
                            Log.w(TAG, "parking from server is not in supertile: " + id);
                            continue;
                        }
//                        Log.v(TAG, "added parking in tile " + i + "," + j);
                        newtiles[i][j].parkings.add(newparking);
                    }
                    
                    Log.d(TAG, "parsing took " + (-time + (time=System.currentTimeMillis())) + "ms");
                    synchronized(this) { // for cache access and for listeners access
                        for (int i=0; i<SUPERTILE_FACTOR; i++) {
                            for (int j=0; j<SUPERTILE_FACTOR; j++) {
                                MapTile newtile = newtiles[i][j];
                                this.cache.add(newtile);
                            }
                        }
                        for (int i=0; i<SUPERTILE_FACTOR; i++) {
                            for (int j=0; j<SUPERTILE_FACTOR; j++) {
                                MapTile newtile = newtiles[i][j];
                                for (TileUpdateListener listener : this.tileUpdateListeners) {
                                    listener.onTileUpdated(newtile);
                                }
                            }
                        }
                    }
                    Log.d(TAG, "caching and tile update listeners took " + (System.currentTimeMillis() - time) + "ms");
                } else {
                    Log.e(TAG, "jena cannot read " + uri);
                }

            } catch (InterruptedException e) {
                Log.w(TAG, "TileDownloaderThread waiting for event was interrupted", e);
            } catch (Exception e) {
                Log.w(TAG, "TileDownloaderThread almost died of exception", e);
            }
        }
    }

    
    private final MapTile cacheTemplate = new MapTile();
    
    public synchronized MapTile getTile(int latE6, int lonE6) {
        this.cacheTemplate.late6min = latE6;
        this.cacheTemplate.lone6min = lonE6;
        MapTile retval = this.cache.get(this.cacheTemplate);
        if (retval == null) {
            Event request = new Event(new MapTile(this.cacheTemplate), System.currentTimeMillis());
            if (!this.eventPresenceSet.contains(request)) {
                this.eventPresenceSet.add(request);
                // todo only enqueue if the thread is running, otherwise loudly ignore?
                while (!this.eventQueue.offer(request)) {
                    Log.e(TAG, "event queue full, removing old entry!");
                    Event old = this.eventQueue.poll();
                    this.eventPresenceSet.remove(old);
                }
                Log.v(TAG, "added event " + request.tile + " from " + Log.getStackTraceString(new Exception()));
            }
        }
        return retval;
    }
    
    private final List<TileUpdateListener> tileUpdateListeners = new ArrayList<TileUpdateListener>();
    private final List<TileDesirabilityChecker> tileDesirabilityCheckers = new ArrayList<TileDesirabilityChecker>();

    public synchronized void registerTileUpdateListener(TileUpdateListener listener) {
        this.tileUpdateListeners.add(listener);
    }

    public synchronized void registerTileDesirabilityChecker(TileDesirabilityChecker checker) {
        this.tileDesirabilityCheckers.add(checker);
    }
    
    private static class Event {
        public MapTile tile;
        public long timeMillis;
        
        public Event(MapTile tile, long time) {
            this.tile = tile;
            this.timeMillis = time;
        }

        @Override
        public boolean equals(Object o) {
            if (o == null || !(o instanceof Event)) {
                return false;
            }
            Event e = (Event) o;
            return this.tile.equals(e.tile);
        }

        @Override
        public int hashCode() {
            return this.tile.hashCode();
        }
    }
}