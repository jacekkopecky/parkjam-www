package uk.ac.open.kmi.parking.service;

interface TileUpdateListener {

    public abstract void onTileUpdated(MapTile tile);

}