package uk.ac.open.kmi.parking.service;

import java.util.Collection;

import uk.ac.open.kmi.parking.DrawableOverlayItem;
import android.location.Location;

import com.google.android.maps.GeoPoint;

/**
 * this class is the background service that loads parking data (parkings, other things for a map, availability and detailed info) in the background and tells the rest of the application. 
 * @author Jacek Kopecky
 *
 */
public class ParkingsService {
    /**
     * the granularity at which the server is contacted, any map request will use a tile of this many microdegrees, both in latitude and longitude
     * todo make this an xml value when this becomes a Service -- NOTE that the value must be big enough to cover the largest distance to the nearest car park
     */
    public static final int TILE_SIZE = 30000; 
    
    // todo ignore all request above 84n and below 84s: a) there aren't any car parks there, b) above that there's a chance near car park would be farther than in the adjoining tile
    
    // todo check the stuff below is all done, when so, move this to documentation
        // the map overlay calls parkingService.currentLocation(minmaxlatlone6...) for the zoomed-in part, the location listener calls parkingService.currentLocation(position)
        // the parking service should know what it has loaded in some sort of LRU cache of map tiles (keep all currently needed ones, and a number (fixed?dynamic?how?) of old ones)
        // when it gets an update of location, it should enqueue loading of its and possibly some adjacent tiles
        // the queue should automatically drop not-yet-satisfied requests that are outside of the current (and adjacent) region (when it gets to them)
        // the main activity should register as a listener on the parking service for change of parkings list in its area of interest
        // and around current location 
    // (register in onResume, unregister in onPause) so that the static parkingsservice doesn't hold reference to potentially disused mainactivity
        // the main activity should propagate the events to the overlay, 
        // but also possibly re-evaluate the nearest car park
    
        // rather than the above, the parking service should give to the overlay a precomputed (volatile) getSortedCurrentParkings(minmaxlatlone6)
    
    // the parking service needs to handle watching for availability updates as well:
    //   both the currently watched car park and the near one (it needs to know about them) most often (twice or more a minute?)
    //   the currently visible car parks every now and then (configurable?) - especially when the watched one (if none, the near one) becomes full
    //   the main activity should register as a listener on the parking service (in onResume and unregister in onPause), and propagate avaliability update events to the overlay and to currpark
    
    // todo now - but I should soon tackle the thread starting-stopping question
    // the parking service also needs to handle detailed data about car parks (getting ttl information from http headers) 
    //   the details should be kept in parking tiles (to be disposed of as above), or in LRU dedicated for parking details? initially the first will be easier
    //   it should load in the background the data for the currently watched car park
    //   also for the one that the user shows a bubble for (again, enqueuing the requests and ignoring the ones that no longer apply)
    //   so overlay and main activity? should tell the service about those UI events that affect the desirability of detailed info
    //   the detailed view should register as a listener on the parking service, automatically giving priority to its request (if still enqueued) and be called if any update comes
    //     register in onResume and unregister in onPause
    
    // listeners supported by parking service:
    // ParkingAvailabilityChange
    // ParkingDetailsChange
        // ParkingsListChange - SortedCurrentItemsUpdateListener, NearCurrentItemsUpdateListener
    
    
    // todo check that for every registerListener there is an unregisterListener, maybe without exceptions
    
    // todo the service should be in the foreground if watching a car park when parkme is not active - also when details activity is on
    // the service should tell a restarting parkme what car park is being watched
    
    /**
     * default constructor
     */
    private ParkingsService() {
        this.tileDownloader = new TileDownloaderThread();
        new Thread(this.tileDownloader).start();
        this.sortingPrecomputationThread = new SortingPrecomputationThread(this.tileDownloader);
        new Thread(this.sortingPrecomputationThread).start();
        this.nearPrecomputationThread = new NearPrecomputationThread(this.tileDownloader);
        new Thread(this.nearPrecomputationThread).start();
        // todo threads should be started and stopped as the main activity starts/stops - use Thread.interrupt(), and should the classes know about it? - should they unregister listeners?
    }
    
    private static ParkingsService instance;
    /**
     * there should only ever be one instance of parkings service
     * todo this should change when ParkingsService becomes Android service
     * @return a singleton parkings service
     */
    public static synchronized ParkingsService get() {
        if (instance == null) {
            instance = new ParkingsService();
        }
        return instance;
    }
    
    private SortingPrecomputationThread sortingPrecomputationThread;
    private NearPrecomputationThread nearPrecomputationThread;
    private TileDownloaderThread tileDownloader;
    
    /**
     * returns (quickly) a precomputed collection of drawable overlay items for the given map
     * todo extract this into a DrawableOverlayItemContainer interface? there should be multiple impls for this because we want parkings, businesses, events etc.
     * @param mapCenter center of the map
     * @param longitudeSpan width of the map
     * @param latitudeSpan height of the map
     * @return a collection of drawable overlay items, sorted north-to-south
     */
    public Collection<DrawableOverlayItem> getSortedCurrentItems(GeoPoint mapCenter, int longitudeSpan, int latitudeSpan) {
        // forward the location to the sorting precomputation thread
        this.sortingPrecomputationThread.onNewCoordinates(new MapRectangle(mapCenter.getLatitudeE6()-latitudeSpan/2, mapCenter.getLongitudeE6()-longitudeSpan/2, mapCenter.getLatitudeE6()+latitudeSpan/2, mapCenter.getLongitudeE6()+longitudeSpan/2));
        return this.sortingPrecomputationThread.sortedCurrentItems;
    }
    
    /**
     * returns (quickly) the current a precomputed collection of drawable overlay items
     * @return a collection of drawable overlay items, sorted north-to-south
     */
    public Collection<DrawableOverlayItem> getSortedCurrentItems() {
        return this.sortingPrecomputationThread.sortedCurrentItems;
    }
    
    /**
     * returns (quickly) a precomputed collection of drawable overlay items near the given location
     * @param location the location
     * @return a collection of drawable overlay items
     */
    public Collection<DrawableOverlayItem> getCurrentItems(Location location) {
        // forward the location to the near precomputation thread
        this.nearPrecomputationThread.onNewCoordinates(location);
        return this.nearPrecomputationThread.nearCurrentItems;
    }

    /**
     * register a listener for updates of the current sorted items collection
     * @param listener the listener
     */
    public synchronized void registerSortedCurrentItemsUpdateListener(SortedCurrentItemsUpdateListener listener) {
        this.sortingPrecomputationThread.registerUpdateListener(listener);
    }
    
    /**
     * register a listener for updates of the current near items collection
     * @param listener the listener
     */
    public synchronized void registerNearCurrentItemsUpdateListener(NearCurrentItemsUpdateListener listener) {
        this.nearPrecomputationThread.registerUpdateListener(listener);
    }
    
    public void onMainActivityResume() {
        // todo start threads
    }
    
    public void onMainActivityPause() {
        // todo stop threads
    }
}
