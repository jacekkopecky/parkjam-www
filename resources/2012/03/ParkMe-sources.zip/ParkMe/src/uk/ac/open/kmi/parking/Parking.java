package uk.ac.open.kmi.parking;

import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;

import com.google.android.maps.GeoPoint;

/**
 * a single parking with all information we have about it
 * @author Jacek Kopecky
 *
 */
public class Parking extends DrawableOverlayItem {
    /**
     * precomputed floating-point latitude
     */
    public final double latitude;
    /**
     * precomputed floating-point longitude
     */
    public final double longitude;
    
    @SuppressWarnings("javadoc")
    public static enum Availability { FULL, AVAILABLE, UNKNOWN };

    /**
     * whether the car park is avaiable 
     * todo replace by a more detailed status - available, full, unknown
     */
    public Availability available;
    
    // todo add detailsRdfTriples when I have an in-memory RDF model?
    
    private static Drawable drawFull = null;
    private static Drawable drawAvailable = null;
    private static Drawable drawUnknown = null;
    private static Rect boundsFull = null;
    private static Rect boundsAvailable = null;
    private static Rect boundsUnknown = null;
    
    /**
     * constructor, fills all the fields
     * @param point location
     * @param title car park name
     * @param id RDF id
     * @param available availability status
     */
    public Parking(GeoPoint point, String title, Uri id, Availability available) {
        super(point, title, "subtitle not used at the moment", id);
        this.latitude = point.getLatitudeE6() / 1000000.;
        this.longitude = point.getLongitudeE6() / 1000000.;
        this.available = available;
    }

    /* *
     * constructor, fills all the fields
     * @param lat latitude
     * @param lon longitude
     * @param title car park name
     * @param id RDF id
     * @param available availability status
     * /
    public Parking(double lat, double lon, String title, Uri id, boolean available) {
        super(new GeoPoint((int)(lat*1e6), (int)(lon*1e6)), title, "subtitle not used at the moment", id);
        this.latitude = lat;
        this.longitude = lon;
        this.available = available;
    }*/

    @Override
    public Drawable getDrawable() {
        if (drawFull == null) {
            throw new IllegalStateException("must use Parking.setDrawables() before using Parking instances in an overlay");
        } 
        Drawable retval = null;
        switch (this.available) {
        case AVAILABLE:
            retval = drawAvailable;
            retval.setBounds(boundsAvailable);
            break;
        case FULL:
            retval = drawFull;
            retval.setBounds(boundsFull);
            break;
        case UNKNOWN: 
            retval = drawUnknown;
            retval.setBounds(boundsUnknown);
            break;
        }
        return retval;
    }
    
    /**
     * sets the drawables to be used for full and available parkings
     * @param full drawable for full parkings
     * @param fullBounds the bounds for the drawable for full parkings - this can be used to put the origin point in the center (an icon), or at the bottom middle (a pin in the map)
     * @param available drawable for available parkings
     * @param availableBounds the bounds for the drawable for available parkings
     * @param unknown drawable for parkings with unknown availability
     * @param unknownBounds the bounds for the drawable for unknown-availability parkings
     */
    public static void setDrawables(Drawable full, Rect fullBounds, Drawable available, Rect availableBounds, Drawable unknown, Rect unknownBounds) {
        drawFull = full;
        drawAvailable = available;
        drawUnknown = unknown;
        boundsFull = fullBounds;
        boundsAvailable = availableBounds;
        boundsUnknown = unknownBounds;
    }
}
