package uk.ac.open.kmi.parking.service;

import java.util.LinkedHashMap;

/**
 * this class implements an Least Recently Used cache of objects of type T
 * currently uses fixed size, todo see if needs to be more dynamic, maybe connected to java garbage collection
 * when an object is removed, the 
 * this queue is NOT synchronized in any way
 * @author Jacek Kopecky
 *
 * @param <T> type of object in the queue
 */
class LRUCache <T> {
    private final int size;
    private LinkedHashMap<T,T> objects;     
    
    public LRUCache(int capacity) {
        this.size = capacity;
        this.objects = new LinkedHashMap<T,T>(this.size+1, .5f, true) {
            private static final long serialVersionUID = 1L;

            @Override
            protected boolean removeEldestEntry(Entry<T, T> eldest) {
                return size() > LRUCache.this.size;
            }
        };
    }
    
    /** 
     * adds an object at the end of the queue
     * @param object the object to be added
     */
    public void add(T object) {
        this.objects.put(object, object);
    }
    
    /**
     * checks whether an objects is in the cache through a template (which must evaluate as equal to the requested object), and makes the object the freshest one in the cache
     * @param template an object that must evaluate as equal to the desired object
     * @return the actual object that was in the cache, or null if it wasn't
     */
    public T get(T template) {
        return this.objects.get(template);
    }
    
    public boolean peek(T template) {
        return this.objects.containsKey(template);
    }
}
