package uk.ac.open.kmi.parking.service;

class MapRectangle {
    public int latmin, lonmin, latmax, lonmax;
    public MapRectangle(int lami, int lomi, int lama, int loma) {
        this.latmin = lami;
        this.lonmin = lomi;
        this.latmax = lama;
        this.lonmax = loma;
    }
    
    public MapRectangle(MapRectangle r) {
        this.latmin = r.latmin;
        this.lonmin = r.lonmin;
        this.latmax = r.latmax;
        this.lonmax = r.lonmax;
    }

    @Override
    public String toString() {
        return "" + this.latmin + " " + this.lonmin + " " + this.latmax + " " + this.lonmax;
    }
}