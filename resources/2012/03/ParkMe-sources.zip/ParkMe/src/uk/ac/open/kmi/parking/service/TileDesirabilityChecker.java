package uk.ac.open.kmi.parking.service;

interface TileDesirabilityChecker {
    
    public boolean isTileDesirable(MapTile tile);

}
