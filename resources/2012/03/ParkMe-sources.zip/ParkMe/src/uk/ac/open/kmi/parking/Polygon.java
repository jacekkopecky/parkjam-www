package uk.ac.open.kmi.parking;

import com.google.android.maps.GeoPoint;

/**
 * this class implements a geopoint defined as the average of a bunch of points - later it could be upgraded to be an actual polygon that a parking could draw
 * todo treat this as an actual polygon
 * @author Jacek Kopecky
 *
 */
public class Polygon extends GeoPoint {
    /**
     * creates a polygon from a list of coordinates - the list must consist of pairs of latitude/longitude (*1e6) pairs, for example new Polygon(1,2,3,4,5,6) is a triangle between the points 1,2; 3,4 and 5,6. 
     * @param latlone6 a list of pairs of latitude and longitude in microdegrees
     */
    public Polygon(int... latlone6) {
        super(avg(0,latlone6), avg(1,latlone6));   // *2 because the length is twice the number of points
    }
    
    private static int avg(int offset, int[] latlone6) {
        if ((latlone6.length | 1) == 1) {
            throw new IllegalArgumentException("Polygon constructor must get an even number of agruments, each two subsequent params forming a latitude/longitude pair");
        }
        long sum = 0;
        for (int i=offset; i< latlone6.length; i+=2) {
            sum += latlone6[i];
        }
        return (int)(sum*2/latlone6.length); // *2 because the length is twice the number of points
    }
}
