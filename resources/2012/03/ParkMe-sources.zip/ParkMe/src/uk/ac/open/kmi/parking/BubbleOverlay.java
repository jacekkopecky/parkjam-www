package uk.ac.open.kmi.parking;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.Interpolator;
import android.view.animation.TranslateAnimation;
import android.widget.RelativeLayout;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.Projection;

/**
 * a map overlay that contains some DrawableOverlayItems
 * @author Jacek Kopecky
 *
 */
public class BubbleOverlay extends Overlay {
    
    private final Drawable bubbleDrawable;
    private final int bubbleTextSize;
    private final ViewGroup placeholderAbsoluteLayout;
    
    private DrawableOverlayItem item = null;
    
    // pre-computed data for draw()
    private final Rect bdb = new Rect(); // bubble drawable bounds
    private final Point textarea = new Point(); // text area bounds
    private final Point currPoint = new Point(); // latest drawn origin of the bubble
    private StaticLayout title; // the drawable with the title
    
    private int lastCanvasWidth = 1000;
    
    private boolean animating = false;
    
    private MainActivity activity;
    
    /**
     * default constructor, no shadow
     * @param bubble drawable for the bubble, best a nine-patch
     * @param bubbleTextSize font size for the text in the bubble
     * @param placeholderAbsoluteLayout where the buble view should be added for animation
     * @param activity the activity to notify about the selected item (and to use as context)
     */
    public BubbleOverlay(Drawable bubble, int bubbleTextSize, ViewGroup placeholderAbsoluteLayout, MainActivity activity) {
        this.bubbleDrawable = bubble;
        this.bubbleTextSize = bubbleTextSize;
        this.placeholderAbsoluteLayout = placeholderAbsoluteLayout;
        this.activity = activity;
    }
    
    /**
     * set item to show in the bubble, set it to null to remove the bubble
     * WARNING: this must be called from the UI thread that calls draw()
     * @param item the item to show in the bubble, null if no bubble should be shown
     */
    public void setItem(DrawableOverlayItem item) {
        if (this.animating) {
            // ignore new car parks while one bubble is being animated out
            return;
        }
        this.item = item;
        if (item != null) {
            computeDrawParams();
        }
    }
    
    /**
     * returns the current bubble item
     * @return the current bubble item, may be null
     */
    public DrawableOverlayItem getItem() {
        return this.item;
    }
    
    private final Rect tmpPadding = new Rect();
    
    private void computeDrawParams() {
        // precompute whatever is needed in draw()
        
        this.bdb.left = -this.bubbleDrawable.getIntrinsicWidth()/2+1;
        this.bdb.right = this.bubbleDrawable.getIntrinsicWidth()/2;
        this.bdb.top = this.item.getDrawable().getBounds().bottom - 16;   // todo the 16 is for the current nine-patch
        this.bdb.bottom = this.bdb.top + this.bubbleDrawable.getIntrinsicHeight();
        
        this.bubbleDrawable.getPadding(this.tmpPadding);
        this.textarea.x = this.bdb.left + this.tmpPadding.left;
        int textareaWidth = this.bdb.right - this.tmpPadding.right - this.textarea.x;
        this.textarea.y = this.bdb.top + this.tmpPadding.top;
        int textareaHeight = this.bdb.bottom - this.tmpPadding.bottom - this.textarea.y;
        
        TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        tp.setColor(Color.WHITE);
        tp.setTypeface(Typeface.DEFAULT_BOLD);
        tp.setTextSize(this.bubbleTextSize);
        int titleWidth = (int)(StaticLayout.getDesiredWidth(this.item.getTitle(), tp)+5); // +5 so that any font padding fits in here
        int maxWidth = this.lastCanvasWidth + textareaWidth - this.bdb.width();  // the bubble should fit in the map view
        if (titleWidth > maxWidth) {
            titleWidth = maxWidth;
        }
        this.title = new StaticLayout(this.item.getTitle(), tp, titleWidth, android.text.Layout.Alignment.ALIGN_CENTER, 1, 0, true);

        titleWidth = this.title.getWidth();
        int titleHeight = this.title.getHeight();
        
        if (titleWidth > textareaWidth) {
            int d = (titleWidth - textareaWidth)/2;
            this.bdb.left -= d;
            this.bdb.right += d;
            this.textarea.x -= d;
        }
        if (titleHeight > textareaHeight) {
            this.bdb.bottom += titleHeight - textareaHeight;
        } else {
            // center the text vertically in the text area
            this.textarea.y += (textareaHeight - titleHeight)/2;
        }
    }
    
    @Override
    public void draw(Canvas canvas, MapView mapView, boolean shadow) {
        if (shadow) {
            return;
        }
        
        if (this.item == null) {
            return;
        }
        
        int width = canvas.getWidth();
        if (width != this.lastCanvasWidth) {
            this.lastCanvasWidth = width;
            computeDrawParams();
        }
        
        mapView.getProjection().toPixels(this.item.getPoint(), this.currPoint);
        doBubbleDraw(canvas, this.currPoint);
    }
    
    private void doBubbleDraw(Canvas canvas, Point offset) {
        this.bubbleDrawable.setBounds(this.bdb.left + offset.x, this.bdb.top + offset.y, this.bdb.right + offset.x, this.bdb.bottom + offset.y);
        this.bubbleDrawable.draw(canvas);
        
        canvas.save();
        canvas.translate(this.textarea.x + offset.x, this.textarea.y + offset.y);
        this.title.draw(canvas);
        canvas.restore();
    }
    
    // cache to avoid creating new points all the time
    private final Point tmpTappedLocation = new Point();
    private final Point tmpBubbleLocation = new Point();

    @Override
    public boolean onTap(GeoPoint point, MapView mapView) {
        if (this.item == null) {
            return false;
        }
        
        Projection proj = mapView.getProjection();
        proj.toPixels(point, this.tmpTappedLocation);
        proj.toPixels(this.item.getPoint(), this.tmpBubbleLocation);
        
        // if   bdb + onTapBubble contains onTapTapped            is the same as            if   bdb contains onTapTapped - onTapBubble
        if (this.bdb.contains(this.tmpTappedLocation.x - this.tmpBubbleLocation.x, this.tmpTappedLocation.y-this.tmpBubbleLocation.y)) {
            animateBubbleAway(mapView);
            // todo set it as the watched car park in the main activity, when the animation ends
            return true;
        }

        return false;
    }

    private void animateBubbleAway(MapView mapView) {
        // load animation
        //     anticipate interpolator for y, with tension growing as the distance is smaller
        //     duration X translation in y from zero to -(point.y + this.textarea.x)
        //     accel/decel interpolator for x
        //     duration X translation in x from zero to -(point.x-mapView.getwidth()/2)
        //     accel interpolator for alpha
        //     start X/2 duration X/2 alpha from 1 to 0
        
        final View bubbleView = new BubbleView(this.activity); 
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(this.bdb.width(), this.bdb.height());
        layoutParams.setMargins(this.bdb.left + this.currPoint.x, this.bdb.top + this.currPoint.y, 0, 0);
        bubbleView.setLayoutParams(layoutParams);
        this.placeholderAbsoluteLayout.addView(bubbleView);
        
        Interpolator smooth = new SmoothAnticipateInterpolator(0);
        
        AnimationSet bubbleFlight = new AnimationSet(false);
        Animation anim = new AlphaAnimation(1, 0);
        anim.setInterpolator(smooth);
        bubbleFlight.addAnimation(anim);
        
        int dy = -(this.currPoint.y);
        anim = new TranslateAnimation(0, 0, 0, dy);
        dy = Math.abs(dy) + 1;  // + 1 to avoid dy ever being 0
        Interpolator ip = null;
        int threshold = mapView.getHeight()*4/10; 
        if (dy > threshold) {
            ip = smooth;
        } else {
            // set y translation's interpolator's tension to grow as the distance is smaller
            ip = new SmoothAnticipateInterpolator(((double)(threshold-dy))/dy);
        }
        anim.setInterpolator(ip);
        bubbleFlight.addAnimation(anim);
        
        anim = new TranslateAnimation(0, -(this.currPoint.x - mapView.getWidth()/2), 0, 0);
        anim.setInterpolator(smooth);
        bubbleFlight.addAnimation(anim);

        bubbleFlight.setDuration(this.activity.getResources().getInteger(R.integer.bubble_flight_animation_duration));
        bubbleFlight.setAnimationListener(new AnimationListener() {
            private final DrawableOverlayItem cachedItem = BubbleOverlay.this.item;
            public void onAnimationStart(Animation animation) {/*nop*/}
            public void onAnimationRepeat(Animation animation) {/*nop*/}
            public void onAnimationEnd(Animation animation) {
                BubbleOverlay.this.placeholderAbsoluteLayout.removeView(bubbleView);
                BubbleOverlay.this.animating = false;
                if (this.cachedItem != null && this.cachedItem instanceof Parking) {
                    BubbleOverlay.this.activity.setCurrentCarpark((Parking)this.cachedItem);
                }
            }
        });
        setItem(null);
        this.animating = true;
        bubbleView.startAnimation(bubbleFlight);
    }
    
    private class BubbleView extends View {

        public BubbleView(Context context) {
            super(context);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            return false;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            Point offset = BubbleOverlay.this.tmpBubbleLocation; // why not reuse this
            offset.set(-BubbleOverlay.this.bdb.left, -BubbleOverlay.this.bdb.top);
            BubbleOverlay.this.doBubbleDraw(canvas, offset);
        }

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            setMeasuredDimension(BubbleOverlay.this.bdb.width(), BubbleOverlay.this.bdb.height());
        }
        
    }

}
