package uk.ac.open.kmi.parking;

import java.util.Collection;

import uk.ac.open.kmi.parking.service.ParkingsService;

import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.Projection;

/**
 * a map overlay that contains some DrawableOverlayItems
 * @author Jacek Kopecky
 *
 */
public class DrawableItemsOverlay extends Overlay {
    
    /**
     * this collection contains the items of this overlay; 
     * it's a collection for now because I don't know what operations will be most used on it
     */
//    public final Collection<T> items = Collections.synchronizedCollection(new TreeSet<T>(new DrawableOverlayItem.Comparator()));
    
    private final boolean noShadow;
    
    private ParkingsService drawableItemContainer;
    
    private final BubbleOverlay bubbleOverlay;
    
    private final float mpiThresholdFull;
    private final float mpiThresholdTinyFirst;
    private final float mpiThresholdTinyLast;
    private final float mpiThresholdNone;
    
    private static final float TINY_ICON_SIZE = .6f;
    
    private float pixDensity;
    
    /**
     * sets whether the overlay should have a shadow
     * @param shadow whether the overlay should have shadows of the icons
     * @param bubble overlay for the bubbles created on a tap
     * @param full if the screen shows up to this many mpi, show full-sized icons
     * @param tinyFirst if the screen shows between full and tiny mpi, show smaller icons
     * @param tinyLast if the screen shows between tinyLast and none mpi, make small icons transparent
     * @param none above none mpi on the screen don't draw any icons
     * @param drawableItemContainer the container for drawable items (todo should be an interface DrawableOverlayItemContainer or somesuch)
     * @param density dpi of the screen
     */
    public DrawableItemsOverlay(boolean shadow, BubbleOverlay bubble, float full, float tinyFirst, float tinyLast, float none, ParkingsService drawableItemContainer, float density) {
        this.noShadow = !shadow;
        this.bubbleOverlay = bubble;
        this.mpiThresholdFull = full;
        this.mpiThresholdTinyFirst = tinyFirst;
        this.mpiThresholdTinyLast = tinyLast;
        this.mpiThresholdNone = none;
        this.drawableItemContainer = drawableItemContainer;
        this.pixDensity = density;
    }
    
    /**
     * sets whether the overlay should have a shadow
     * @param shadow whether the overlay should have shadows of the icons
     * @param bubble overlay for the bubbles created on a tap
     * @param full if the screen shows up to this many mpi, show full-sized icons
     * @param tinyFirst if the screen shows between full and tiny mpi, show smaller icons
     * @param tinyLast if the screen shows between tinyLast and none mpi, make small icons transparent
     * @param none above none mpi on the screen don't draw any icons
     * @param drawableItemContainer the container for drawable items
     */
    public DrawableItemsOverlay(boolean shadow, BubbleOverlay bubble, float full, float tinyFirst, float tinyLast, float none, ParkingsService drawableItemContainer) {
        this(shadow, bubble, full, tinyFirst, tinyLast, none, drawableItemContainer, 160);
    }
    
    /**
     * default constructor, no shadow
     * @param bubble drawable for the bubble, best a nine-patch
     * @param full if the screen shows up to this many mpi, show full-sized icons
     * @param tinyFirst if the screen shows between full and tiny mpi, show smaller icons
     * @param tinyLast if the screen shows between tinyLast and none mpi, make small icons transparent
     * @param none above none mpi on the screen don't draw any icons
     * @param drawableItemContainer the container for drawable items
     */
    public DrawableItemsOverlay(BubbleOverlay bubble, float full, float tinyFirst, float tinyLast, float none, ParkingsService drawableItemContainer) {
        this(false, bubble, full, tinyFirst, tinyLast, none, drawableItemContainer, 160);
    }
    
    private static final Rect tmpRect = new Rect();

    private float currentSize = 1;
    
    @Override
    public void draw(Canvas canvas, MapView mapView, boolean shadow) {
        if (this.noShadow && shadow) {
            return;
        }

        Projection proj = mapView.getProjection();

        float pxEquatorMeter = proj.metersToEquatorPixels(100000f)/100000f;  // 100000 to get useful accuracy
        float mpi = this.pixDensity/pxEquatorMeter;
        // around latitude 50, that's ca 64cm
//        android.util.Log.d("parkme", "mpi is " + mpi);

//        boolean disappearing = false;
        if (mpi > this.mpiThresholdNone) {
            this.currentSize = 0f;
            if (this.bubbleOverlay.getItem() != null) {
                this.bubbleOverlay.setItem(null);
                mapView.invalidate();
            }
            MainActivity.setTooFarOut(true, mapView.getContext());
            return; // no need to show anything, we're zoomed too far out
        } else if (mpi < this.mpiThresholdFull) {
            this.currentSize = 1f;
        } else if (mpi < this.mpiThresholdTinyFirst) {
            // normal to tiny
            this.currentSize = TINY_ICON_SIZE + (1-TINY_ICON_SIZE)*(this.mpiThresholdTinyFirst-mpi)/(this.mpiThresholdTinyFirst-this.mpiThresholdFull);
        } else if (mpi < this.mpiThresholdTinyLast) {
            this.currentSize = TINY_ICON_SIZE;
        } else {
            // tiny to disappearance
//            disappearing=true;
            this.currentSize = TINY_ICON_SIZE * (this.mpiThresholdNone-mpi)/(this.mpiThresholdNone-this.mpiThresholdTinyLast);
        }
        MainActivity.setTooFarOut(false, mapView.getContext());
        
//        android.util.Log.d("parkme", "currentSize " + this.currentSize);

        
        // todo group to avoid overlapping?
        Point point = new Point();
        Collection<DrawableOverlayItem> items;
//        if (disappearing) {
//            // above tiny last call getSortedCurrentItems() no params cos we're too far out and showing only tiny miniature markers so we shouldn't be loading any more tiles around
//            items = this.drawableItemContainer.getSortedCurrentItems();
//        } else { 
            items = this.drawableItemContainer.getSortedCurrentItems(mapView.getMapCenter(), mapView.getLongitudeSpan(), mapView.getLatitudeSpan()); 
//        }
        for (DrawableOverlayItem item : items) {
            proj.toPixels(item.getPoint(), point);
            Drawable drawable = item.getDrawable();
            drawable.copyBounds(tmpRect);
            drawable.setBounds((int)(tmpRect.left * this.currentSize), (int)(tmpRect.top * this.currentSize), (int)(tmpRect.right * this.currentSize), (int)(tmpRect.bottom * this.currentSize));
            drawAt(canvas, drawable, point.x, point.y, shadow);
            drawable.setBounds(tmpRect);
        }
    }

    @Override
    public boolean onTap(GeoPoint point, MapView mapView) {
        // todo a double click could probably be catchable here, zooming in by mapController.zoominfixing or somesuch
        
        // todo onTap should not be fired on release of pinch zoom
        DrawableOverlayItem tapped = null;
        Projection proj = mapView.getProjection();
        Point pix = proj.toPixels(point, null);
        Point ipix = new Point();
        Collection<DrawableOverlayItem> items = this.drawableItemContainer.getSortedCurrentItems();
        for (DrawableOverlayItem item : items) {
            proj.toPixels(item.getPoint(), ipix);
            int dx = pix.x - ipix.x;
            int dy = pix.y - ipix.y;

            Drawable idr = item.getDrawable();
            idr.copyBounds(tmpRect);
            tmpRect.left *= this.currentSize;
            tmpRect.right *= this.currentSize;
            tmpRect.top *= this.currentSize;
            tmpRect.bottom *= this.currentSize;

            if ((dx > tmpRect.left) && (dx < tmpRect.right) && (dy > tmpRect.top) && (dy < tmpRect.bottom) ) {
                tapped = item;
                // todo if we go throuth this.items in reverse order (possible with TreeSet from API 9) we could break after the first one is found because it's the top one
                // break;
            }
        }
        
        if (tapped != null) {
            this.bubbleOverlay.setItem(tapped);
            mapView.invalidate();
            return true;
        } else {
            if (this.bubbleOverlay.getItem() != null) {
                this.bubbleOverlay.setItem(null);
                mapView.invalidate();
                return true;
            } else {
                return false;
            }
        }
    }
}
