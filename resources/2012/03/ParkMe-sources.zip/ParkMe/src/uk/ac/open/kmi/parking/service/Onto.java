package uk.ac.open.kmi.parking.service;

import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.ResourceFactory;

// todo make this shared between server and client code
@SuppressWarnings("javadoc")
public class Onto {

    public static final String GEO = "http://www.w3.org/2003/01/geo/wgs84_pos#";
    public static final String LGO = "http://linkedgeodata.org/ontology/";
    public static final String PARKING = "http://parking.kmi.open.ac.uk/todo/onto#";

    private static final Resource resource(String uri, String local) {
        return ResourceFactory.createResource(uri + local);
    }

    private static final Property property(String uri, String local) {
        return ResourceFactory.createProperty(uri + local);
    }


    public static final Resource LGOParking = resource( LGO, "Parking" );

    public static final Property GEOlat = property( GEO, "lat" );
    public static final Property GEOlong = property( GEO, "long" );
    
    public static final Property PARKINGavailable = property ( PARKING, "available");

//    /**
//        The same items of vocabulary, but at the Node level, parked inside a
//        nested class so that there's a simple way to refer to them.
//    */
//    @SuppressWarnings("hiding") public static final class Nodes
//        {
//        public static final Node Alt = Ontologies.Alt.asNode();
//        public static final Node Bag = Ontologies.Bag.asNode();
//        public static final Node Property = Ontologies.Property.asNode();
//        public static final Node Seq = Ontologies.Seq.asNode();
//        public static final Node Statement = Ontologies.Statement.asNode();
//        public static final Node List = Ontologies.List.asNode();
//        public static final Node nil = Ontologies.nil.asNode();
//        public static final Node first = Ontologies.first.asNode();
//        public static final Node rest = Ontologies.rest.asNode();
//        public static final Node subject = Ontologies.subject.asNode();
//        public static final Node predicate = Ontologies.predicate.asNode();
//        public static final Node object = Ontologies.object.asNode();
//        public static final Node type = Ontologies.type.asNode();
//        public static final Node value = Ontologies.value.asNode();
//        }
//
}
