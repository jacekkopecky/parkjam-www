package uk.ac.open.kmi.parking.service;

import java.util.ArrayList;
import java.util.Collection;

import uk.ac.open.kmi.parking.Parking;

class MapTile {
    public MapTile() {};
    
    public MapTile(MapTile o) {
        this.late6min = o.late6min;
        this.lone6min = o.lone6min;
        if (o.parkings != null) {
            this.parkings = new ArrayList<Parking>(o.parkings);
        }
    }
    
    public int late6min, lone6min;
    public Collection<Parking> parkings;
    // todo store car parks here, with detailed information (which may go to a different LRU later) and availability
    
    
    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof MapTile)) { 
            return false; 
        }
        MapTile omr = (MapTile) o;
        return this.late6min == omr.late6min && this.lone6min == omr.lone6min;
    }
    
    private static final int OFFSET = 360000000/ParkingsService.TILE_SIZE;
    
    @Override
    public int hashCode() {
        return this.late6min/ParkingsService.TILE_SIZE + this.lone6min/ParkingsService.TILE_SIZE*OFFSET;
    }
    
    @Override
    public String toString() {
        return "MapTile " + this.late6min + " " + this.lone6min;
    }
}