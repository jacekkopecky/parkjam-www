package uk.ac.open.kmi.parking.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import uk.ac.open.kmi.parking.DrawableOverlayItem;
import android.location.Location;
import android.util.Log;

class NearPrecomputationThread implements Runnable, TileUpdateListener, TileDesirabilityChecker {
        private static final String TAG = "near-precompute thread";
        volatile Collection<DrawableOverlayItem> nearCurrentItems = Collections.emptyList();
        private volatile MapRectangle currentCoveredCoordinatesE6 = null;
        private final BlockingQueue<Event> eventQueue = new ArrayBlockingQueue<Event>(1000); // todo make this number configurable? also the number of updatedTiles below
        private TileDownloaderThread tileDownloader;
        
        public NearPrecomputationThread(TileDownloaderThread tileDownloader) {
            this.tileDownloader = tileDownloader;
            tileDownloader.registerTileUpdateListener(this);
            tileDownloader.registerTileDesirabilityChecker(this);
        }
        
        // todo E0 is a bad mnemonic, it's actually E1, or rather E6/TILE_SIZE
        private int lastTileMinLatE0 = Integer.MIN_VALUE;
        private int lastTileMinLonE0 = Integer.MIN_VALUE;
        private int lastTileMaxLatE0 = Integer.MAX_VALUE;
        private int lastTileMaxLonE0 = Integer.MAX_VALUE;
        private Location lastCoords = null;
        
        private final List<MapTile> updatedTiles = new ArrayList<MapTile>(1000);
        private int maxQueueSize = 0;

        public void run() {
            for (;;) {
                try {
                    int queueSize = this.eventQueue.size();
                    if (queueSize > this.maxQueueSize) {
                        this.maxQueueSize = queueSize;
                        Log.i(TAG, "queue size maximum increased to " + this.maxQueueSize);
                        // todo check that this is sane over longer lives of the app, possibly lower the size of the queue - just under a 100 is OK because of tile update events from newly-loaded supertiles
                    }

                    Event event = this.eventQueue.take();
                    // in case the events are only tile updates, we want to act on the last coordinates
                    Location coords = this.lastCoords;
                    do {
                        switch (event.type) {
                        case NEW_COORDINATES:
                            coords = event.coords;
                            break;
                        case TILE_UPDATE:
                            this.updatedTiles.add(event.tile);
                            break;
                        }
                        event = this.eventQueue.poll();
                    } while (event != null);
                    
                    if (coords == null) {
                        continue;
                    }
                    
                    boolean forceUpdate = this.lastCoords == null;
                    if (!forceUpdate) {
                        for (MapTile tile : this.updatedTiles) {
                            int tileLatE0 = tile.late6min / ParkingsService.TILE_SIZE;
                            int tileLonE0 = tile.lone6min / ParkingsService.TILE_SIZE;
                            if (tileLatE0 >= this.lastTileMinLatE0 &&
                                    tileLonE0 >= this.lastTileMinLonE0 &&
                                    tileLatE0 <= this.lastTileMaxLatE0 &&
                                    tileLonE0 <= this.lastTileMaxLonE0) {
                                forceUpdate = true;
                                break;
                            }
                        }
                    }
                    this.updatedTiles.clear();
                    
                    // for now we simply combines the parks in the 3x3 tiles centered on the coordinates
                    // there is a buffer zone in which the current-precomputed is still acceptable
                    // it can be optimized to 1-to-4 (depending on where in its tile the point is)

                    
                    this.lastCoords = coords;

                    // the tiles that are at least partially visible
                    int late6 = (int) Math.floor(coords.getLatitude()*1e6);
                    int lone6 = (int) Math.floor(coords.getLongitude()*1e6);
                    
                    int tileLatE0 = late6 / ParkingsService.TILE_SIZE; if (late6 < 0) tileLatE0--;
                    int tileLonE0 = lone6 / ParkingsService.TILE_SIZE; if (lone6 < 0) tileLonE0--;

                    // the stuff with % is about whether more than a half of the border tile is visible (so we don't really necessarily have space next to it)
                    
                    // first check that the new request isn't already satisfied
                    if (forceUpdate || 
                            ((tileLatE0 == this.lastTileMinLatE0) && (late6 - tileLatE0*ParkingsService.TILE_SIZE)*2 < ParkingsService.TILE_SIZE) ||
                            (tileLatE0 < this.lastTileMinLatE0) ||
                            ((tileLonE0 == this.lastTileMinLonE0) && (lone6 - tileLonE0*ParkingsService.TILE_SIZE)*2 < ParkingsService.TILE_SIZE) ||
                            (tileLonE0 < this.lastTileMinLonE0) ||
                            ((tileLatE0 == this.lastTileMaxLatE0) && (late6 - tileLatE0*ParkingsService.TILE_SIZE)*2 > ParkingsService.TILE_SIZE) ||
                            (tileLatE0 > this.lastTileMaxLatE0) ||
                            ((tileLonE0 == this.lastTileMaxLonE0) && (lone6 - tileLonE0*ParkingsService.TILE_SIZE)*2 > ParkingsService.TILE_SIZE) ||
                            (tileLonE0 > this.lastTileMaxLonE0)) {
                        // need to recompute
                        
                        int tileMinLatE0 = tileLatE0-1;
                        int tileMinLonE0 = tileLonE0-1;
                        int tileMaxLatE0 = tileLatE0+1;
                        int tileMaxLonE0 = tileLonE0+1;
                        
                        this.lastTileMinLatE0 = tileMinLatE0;
                        this.lastTileMinLonE0 = tileMinLonE0;
                        this.lastTileMaxLatE0 = tileMaxLatE0;
                        this.lastTileMaxLonE0 = tileMaxLonE0;
                        
                        this.currentCoveredCoordinatesE6 = 
                                new MapRectangle(
                                        tileMinLatE0 * ParkingsService.TILE_SIZE,
                                        tileMinLonE0 * ParkingsService.TILE_SIZE, 
                                        tileMaxLatE0 * ParkingsService.TILE_SIZE,
                                        tileMaxLonE0 * ParkingsService.TILE_SIZE);

                        List<DrawableOverlayItem> retval = new ArrayList<DrawableOverlayItem>(200);
                        int count=0; int total=0;
                        // todo this should go from the center, not from the corner
                        for (int latE0 = tileMinLatE0; latE0 <= tileMaxLatE0; latE0++) {
                            for (int lonE0 = tileMinLonE0; lonE0 <= tileMaxLonE0; lonE0++) {
                                MapTile tile = this.tileDownloader.getTile(latE0*ParkingsService.TILE_SIZE, lonE0*ParkingsService.TILE_SIZE);
                                total++;
                                if (tile != null) {
                                    retval.addAll(tile.parkings);
                                    count++;
                                }
                            }
                        }
                        
                        this.nearCurrentItems = retval;
                        // let listeners know about this change
                        synchronized(this) {
                            for (NearCurrentItemsUpdateListener listener : this.updateListeners) {
                                listener.onNearCurrentItemsUpdated();
                            }
                        }
                        Log.d(TAG, "recomputed (with " + count + " out of " + total + " tiles, " + retval.size() + " parkings) for " + coords);
                    } else {
                        // otherwise no need to do anything
//                        Log.i("parkme", "no recomputation for " + event);
                    }
                } catch (InterruptedException e) {
                    Log.i(TAG, "thread interrupted, quitting", e);
                    return;
                } catch (Exception e) {
                    Log.w(TAG, "thread almost died of exception", e);
                }
            }
        }
        
        public void onNewCoordinates(Location coords) {
            boolean added = this.eventQueue.offer(new Event(coords));
            if (!added) {
                Log.e(TAG, "event queue full, cannot add new rectangle!");
            }
        }
        
        public void onTileUpdated(MapTile tile) {
            boolean added = this.eventQueue.offer(new Event(tile));
            if (!added) {
                Log.e(TAG, "event queue full, cannot add new tile!");
            }
        }
        
        private static class Event {
            enum Type { TILE_UPDATE, NEW_COORDINATES };
            final Type type;
            Location coords;
            MapTile tile;
            
            public Event(Location coords) {
                this.coords = coords;
                this.type = Type.NEW_COORDINATES;
            }
            
            public Event(MapTile tile) {
                this.tile = tile;
                this.type = Type.TILE_UPDATE;
            }
        }

        public boolean isTileDesirable(MapTile tile) {
            MapRectangle currentCoveredE6 = this.currentCoveredCoordinatesE6;
            if (currentCoveredE6 == null) {
                return true;
            } else {
                return
                        tile.late6min >= currentCoveredE6.latmin && 
                        tile.late6min <= currentCoveredE6.latmax &&
                        tile.lone6min >= currentCoveredE6.lonmin && 
                        tile.lone6min <= currentCoveredE6.lonmax;
            }
        }
    
        private final List<NearCurrentItemsUpdateListener> updateListeners = new ArrayList<NearCurrentItemsUpdateListener>();

        public synchronized void registerUpdateListener(NearCurrentItemsUpdateListener listener) {
            this.updateListeners.add(listener);
        }
}