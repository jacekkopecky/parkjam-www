package uk.ac.open.kmi.parking;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import uk.ac.open.kmi.parking.Parking.Availability;
import uk.ac.open.kmi.parking.service.NearCurrentItemsUpdateListener;
import uk.ac.open.kmi.parking.service.ParkingsService;
import uk.ac.open.kmi.parking.service.SortedCurrentItemsUpdateListener;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.MyLocationOverlay;
import com.google.android.maps.Overlay;

/**
 * main
 * @author Jacek Kopecky
 *
 */
public class MainActivity extends MapActivity implements OnClickListener, LocationListener, SortedCurrentItemsUpdateListener, NearCurrentItemsUpdateListener {
    private static final String TAG = "main activity";
    private MapView mapView;
    private MyLocationOverlay myLoc;
    private MapController mapController;
    private DrawableItemsOverlay parkingsOverlay;
    private LocationManager locationManager;
    private Button buttonYes = null, buttonNo = null;
    
    private ParkingsService parkingsService = ParkingsService.get();
    
//    public static Collection<Parking> parkings; // todo fix this

    private TextView currentCarparkTextView;
    private Parking currentCarpark = null;
    private Location currentLocation = null; // todo some places use myLoc.getMyLocation, others use this, should be synced up, probably my own MyLocationOverlay should be updated from here
    private boolean followUserLocation = false; // todo not sure about the default
    
    // todo currpark showing "now @ somewhere" may be confusing when the user has moved the map elsewhere
    // todo currpark showing "looking for car parks..." when no car park near is confusing
    // todo there should be some status indicator when car parks are being loaded
    
    // todo another mode: if bubble is selected, currpark could show that instead of the selected one, or it should not be shown at all
    // todo maybe I should be able to turn off following my location, so I'd be in SELECTED but without a car park, which is currently treated as "initial", meaning NEAREST and none found
    // todo when currentCarparkTextView changes its content, it could pull up with the old and then pull down with the new
    private enum Mode {
        SELECTED, NEAREST
    }
    
    private Mode mode = Mode.NEAREST;
    private boolean tooFarOut = false;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        // give LogCat time to catch up
//        try {
//            Thread.sleep(1000);  
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }

        super.onCreate(savedInstanceState);
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN); 
            requestWindowFeature(Window.FEATURE_NO_TITLE);
        }
        setContentView(R.layout.main);
        
        this.buttonYes = (Button) findViewById(R.id.btn_yes);
        this.buttonNo = (Button) findViewById(R.id.btn_no);
        this.buttonYes.setVisibility(View.INVISIBLE);
        this.buttonNo.setVisibility(View.INVISIBLE);

        
        // todo put state information (especially current car park, maybe current location) in bundle ("on freeze") and retrieve it from there ("on thaw") 
        this.currentCarparkTextView = (TextView) findViewById(R.id.currpark);
        this.currentCarparkTextView.setOnClickListener(this);
        registerForContextMenu(this.currentCarparkTextView);
        
        this.mapView = (MapView) findViewById(R.id.mapview);
        this.mapController = this.mapView.getController();
        this.mapView.setBuiltInZoomControls(true);
//        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
//            ZoomButtonsController zoomButtons = this.mapView.getZoomButtonsController();
//            Log.d("parkme", "zoombuttons layout class " + zoomButtons.getZoomControls().getLayoutParams());
//            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(zoomButtons.getZoomControls().getLayoutParams());
//            layoutParams.topMargin = this.buttonYes.getHeight();
//            zoomButtons.getZoomControls().setLayoutParams(layoutParams);
//        }
        
        List<Overlay> overlays = this.mapView.getOverlays();
        
        // set parking drawables
        Drawable drawableFull = this.getResources().getDrawable(R.drawable.parking_full);
        int width = drawableFull.getIntrinsicWidth();
        int height = drawableFull.getIntrinsicHeight();
//        Rect drawableFullBounds = new Rect(-width/2, -height/2, width-width/2, height-height/2);
        Rect drawableFullBounds = new Rect(-width/2, -height, width-width/2, 0);
        Drawable drawableAvailable = this.getResources().getDrawable(R.drawable.parking_available);
        width = drawableAvailable.getIntrinsicWidth();
        height = drawableAvailable.getIntrinsicHeight();
//        Rect drawableAvailableBounds = new Rect(-width/2, -height/2, width-width/2, height-height/2);
        Rect drawableAvailableBounds = new Rect(-width/2, -height, width-width/2, 0);
        Drawable drawableUnknown = this.getResources().getDrawable(R.drawable.parking_busy);
        width = drawableUnknown.getIntrinsicWidth();
        height = drawableUnknown.getIntrinsicHeight();
//        Rect drawableUnknownBounds = new Rect(-width/2, -height/2, width-width/2, height-height/2);
        Rect drawableUnknownBounds = new Rect(-width/2, -height, width-width/2, 0);
        Parking.setDrawables(drawableFull, drawableFullBounds, drawableAvailable, drawableAvailableBounds, drawableUnknown, drawableUnknownBounds);
        
        BubbleOverlay bubbleOverlay = new BubbleOverlay(
                getResources().getDrawable(R.drawable.bubble), 
                getResources().getDimensionPixelSize(R.dimen.bubble_text_size), 
                (ViewGroup)findViewById(R.id.main_layout), 
                this);
        
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        float density = dm.densityDpi;
        
        this.parkingsOverlay = new DrawableItemsOverlay(true, bubbleOverlay,
                getResources().getInteger(R.integer.mpi_threshold_full_carpark_icons),
                getResources().getInteger(R.integer.mpi_threshold_tiny_first_carpark_icons),
                getResources().getInteger(R.integer.mpi_threshold_tiny_last_carpark_icons),
                getResources().getInteger(R.integer.mpi_threshold_no_carpark_icons), 
                parkingsService, 
                density);
        overlays.add(this.parkingsOverlay);
//        this.parkings = this.parkingsOverlay.items;
            
        // this must be added after the parkings and other stuff but before the bubble
        this.myLoc = new MyLocationOverlay(getApplicationContext(), this.mapView); /* todo do something about following my location - disable it when the map is moved by the user, enable when pressing My Location in the menu: { 
            private boolean followLocation = false;
            @Override
            public synchronized void onLocationChanged(Location location) {
                super.onLocationChanged(location);
                if (this.followLocation && isMyLocationEnabled()) {
                    MainActivity.this.mapController.animateTo(getMyLocation());
                }
            }
        }; */
//        this.myLoc.enableMyLocation();
//        this.myLoc.disableCompass();
        overlays.add(this.myLoc);
        
        // this should be the last overlay added
        overlays.add(bubbleOverlay);
        
        // Acquire a reference to the system Location Manager
        this.locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        // todo add overlay for extra things
        
    }
    
    @Override
    public void onResume() {
        super.onResume();
        parkingsService.onMainActivityResume();
        parkingsService.registerSortedCurrentItemsUpdateListener(this);
        parkingsService.registerNearCurrentItemsUpdateListener(this);

//        this.myLoc.enableCompass();
        this.myLoc.enableMyLocation();
        // Register the listener with the Location Manager to receive location updates
        this.locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10000, 20, this);
        this.locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10000, 20, this);
    }
    
    @Override
    public void onPause() {
        this.myLoc.disableCompass();
        this.myLoc.disableMyLocation();
        this.locationManager.removeUpdates(this);
        
        parkingsService.onMainActivityPause();

        super.onPause();
    }

    public void onClick(View v) {
        // this gets called on click on currpark text view
        if (this.tooFarOut || this.currentCarpark == null) {
            return;
        }
        showDetailsForCarpark(this, this.currentCarpark);
    }

    static void setTooFarOut(boolean far, Context context) {
        if (context instanceof MainActivity) {
            MainActivity thiss = (MainActivity)context; 
            if (thiss.tooFarOut != far) {
                thiss.tooFarOut = far;
                thiss.updateUIState();
            }
        } else {
            Log.e(TAG, "context not a MainActivity (when setting tooFarOut)!");
        }
    }

    /**
     * helper method that calls the details view
     * @param context the current activity
     * @param item the parking whose details should be viewed
     */
    public static void showDetailsForCarpark(Context context, DrawableOverlayItem item) {
        Intent intent = new Intent(context, ParkingDetailsActivity.class);
        intent.setData(item.id);
        context.startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_options, menu);
        return true;
    }
    
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        menu.findItem(R.id.menu_traffic).setChecked(this.mapView.isTraffic());
        menu.findItem(R.id.menu_satellite).setChecked(this.mapView.isSatellite());
        menu.findItem(R.id.menu_my_location).setEnabled(this.myLoc.getMyLocation() != null);
        return true;
        
        // todo make "my lcoation" menu item disabled when no current location
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        boolean state;
        switch (item.getItemId()) {
        case R.id.menu_traffic:
            state = item.isChecked();
            item.setChecked(!state);
            this.mapView.setTraffic(!state);
            return true;
        case R.id.menu_satellite:
            state = item.isChecked();
            item.setChecked(!state);
            this.mapView.setSatellite(!state);
            return true;
        case R.id.menu_my_location:
            GeoPoint loc = this.myLoc.getMyLocation();
            this.followUserLocation = true;
            if (loc != null) {
                this.mapController.animateTo(loc);
            } else {
                Toast.makeText(getApplicationContext(), R.string.toast_no_location, Toast.LENGTH_SHORT).show();
            }
            return true;
//        case R.id.map_layers:
//            break;
//        case R.id.settings:
//            break;
        default:
            return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        if (v == this.currentCarparkTextView && !this.tooFarOut && this.currentCarpark != null) {
            getMenuInflater().inflate(R.menu.currpark_context, menu);
            menu.setHeaderIcon(this.currentCarpark.getDrawable());
            menu.setHeaderTitle(this.currentCarpark.getTitle());
            MenuItem follow = menu.findItem(R.id.menu_currpark_follow_nearest);
            // disable and hide 'follow' if we are already following, show otherwise
            if (this.mode == Mode.NEAREST) {
                follow.setVisible(false); follow.setEnabled(false);
            }
            // todo check that the menu entry reappears when I get into selected mode
        }
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        // todo should I check whether this.currentCarpark is null? can it be?
        switch (item.getItemId()) {
        case R.id.menu_currpark_follow_nearest:
            this.mode = Mode.NEAREST;
            findNearestCarPark();
            if (this.currentCarpark != null) {
                this.mapController.animateTo(this.currentCarpark.getPoint());
            }
            // todo this could probably turn on following of the current location on the map
            return true;
        case R.id.menu_currpark_zoom:
            // todo should probably zoom in on current location instead of the car park, but also zoom so that the nearest car park must be visible
            this.mapController.animateTo(this.currentCarpark.getPoint());
            return true;
        case R.id.menu_currpark_mark_available:
            this.currentCarpark.available = Availability.AVAILABLE;
            this.mapView.invalidate();
            return true;
        case R.id.menu_currpark_mark_full:
            this.currentCarpark.available = Availability.FULL;
            this.mapView.invalidate();
            return true;
        case R.id.menu_currpark_show_details:
            showDetailsForCarpark(this, this.currentCarpark);
            return true;
        default:
            return super.onContextItemSelected(item);
        }
    }

    public void onLocationChanged(Location location) {
        // todo filter out fixes that are worse than this one
        // todo only change current near carpark if the accuracy of the fix is good enough (e.g. within the limit distance to the near carpark)
        this.currentLocation = location;
        if (this.mode == Mode.NEAREST) {
            findNearestCarPark();
        }
        if (this.followUserLocation) {
            this.mapController.animateTo(new GeoPoint((int)(location.getLatitude()*1e6), (int)(location.getLongitude()*1e6)));
        }
        
        // todo also make sure that after some time without updates, current location is no longer valid (this may be done by MyLocationOverlay itself), and the menu is disabled again (and that the menu is kept up-to-date in android 3.0+ -- call invalidateOptionsMenu())
    }

    private void findNearestCarPark() {
        this.currentCarpark  = null;
        if (this.currentLocation != null) {
            double distance = getResources().getInteger(R.integer.near_car_park_meters);  // 1km from the nearest car park is too far to be in it
            float[] distresult = new float[1];
            
            Collection<DrawableOverlayItem> parkings = parkingsService.getCurrentItems(this.currentLocation);
            for (Iterator it = parkings.iterator(); it.hasNext();) {
                Parking parking = (Parking) it.next();
                Location.distanceBetween(this.currentLocation.getLatitude(), this.currentLocation.getLongitude(), parking.latitude, parking.longitude, distresult);
                if (distresult[0] < distance) {
                    distance = distresult[0];
                    this.currentCarpark = parking;
                }
            }
        }
        
        updateUIState();
    }

    /**
     * this method takes care of the current car park information text view and the two main buttons
     */
    private void updateUIState() {
        if (this.tooFarOut) {
            this.currentCarparkTextView.setText(R.string.currpark_too_far_out);
            setAvailabilityVisibility(false);
            setButtonsVisibility(false);
        } else if (this.currentCarpark == null) {
            this.currentCarparkTextView.setText(R.string.currpark_initial);
            setAvailabilityVisibility(false);
            setButtonsVisibility(false);
        } else {
            setButtonsVisibility(true);
            setAvailabilityVisibility(true);
            switch (this.mode) {
            case NEAREST: 
                this.currentCarparkTextView.setText(getResources().getString(R.string.currpark_in_car_park) + this.currentCarpark.getTitle());
                break;
            case SELECTED:
                this.currentCarparkTextView.setText(getResources().getString(R.string.currpark_selected) + this.currentCarpark.getTitle());
            }
        }
        // todo the current carpark should be somehow highlighted, maybe glow/pulsate?
        // todo currpark view could have an icon for centering on the selected car park?
    }
    
    private void setAvailabilityVisibility(boolean visible) {
        if (visible) {
            int color = R.color.default_text;
            switch (this.currentCarpark.available) {
            case AVAILABLE:
                color = R.color.btn_yes_text;
                break;
            case FULL:
                color = R.color.btn_no_text;
                break;
            case UNKNOWN:
                // todo default color
                break;
            }
            this.currentCarparkTextView.setTextColor(getResources().getColor(color));
        } else {
            this.currentCarparkTextView.setTextColor(getResources().getColor(R.color.default_text));
        }
    }

    private void setButtonsVisibility(boolean visible) {
        if (visible) {
            this.buttonNo.setEnabled(true);
            this.buttonNo.setVisibility(View.VISIBLE);
            this.buttonYes.setEnabled(true);
            this.buttonYes.setVisibility(View.VISIBLE);
        } else {
            // todo they should grey out, not necessarily disappear
            this.buttonNo.setEnabled(false);
            this.buttonNo.setVisibility(View.INVISIBLE);
            this.buttonYes.setEnabled(false);
            this.buttonYes.setVisibility(View.INVISIBLE);
        }
    }

    public void onProviderDisabled(String provider) { /* do nothing */ }

    public void onProviderEnabled(String provider) { /* do nothing */ }

    public void onStatusChanged(String provider, int status, Bundle extras) { /* do nothing */ }
    
    /**
     * called by the button "full"
     * @param view the button
     */
    public void onButtonPressNo(@SuppressWarnings("unused") View view) {
        if (this.currentCarpark != null && this.currentCarpark.available != Availability.FULL) {
            this.currentCarpark.available = Availability.FULL;
            updateUIState();
            this.mapView.invalidate();
        }
        // todo submit the info
    }
    
    /**
     * called by the button "available"
     * @param view the button
     */
    public void onButtonPressYes(@SuppressWarnings("unused")View view) {
        if (this.currentCarpark != null && this.currentCarpark.available != Availability.AVAILABLE) {
            this.currentCarpark.available = Availability.AVAILABLE;
            updateUIState();
            this.mapView.invalidate();
        }
        // todo submit the info
    }
    
    /**
     * tell the activity that a car park was selected for following, it mustn't be null
     * @param carpark a selected car park, must not be null
     */
    public void setCurrentCarpark(Parking carpark) {
        if (carpark == null) {
            throw new NullPointerException("setCurrentCarpark must not receive null parameter");
        }
        this.mode = Mode.SELECTED;
        this.currentCarpark = carpark;
        updateUIState();
    }

    public void onSortedCurrentItemsUpdated() {
        runOnUiThread(new Runnable(){
            public void run() {
                MainActivity.this.mapView.invalidate();
            }
        });
    }

    public void onNearCurrentItemsUpdated() {
        runOnUiThread(new Runnable(){
            public void run() {
                findNearestCarPark();
            }
        });
    }

    @Override
    protected boolean isRouteDisplayed() {
        return false;
    }

}
