package uk.ac.open.kmi.parking.server;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.StreamingOutput;

import org.openrdf.query.GraphQueryResult;
import org.openrdf.query.QueryLanguage;
import org.openrdf.rio.turtle.TurtleWriter;

import uk.ac.open.kmi.parking.server.Config.MyRepositoryModel;

/**
 * @author Jacek Kopecky
 * PNEAR resource, see deliverables (todo copy description here)
 */
@SuppressWarnings("unqualified-field-access")
@Path("/availetc")
public class AreaAvailabilityEtcResource {
    
    @DefaultValue("360000000") @QueryParam("late6min") int late6min;
    @DefaultValue("360000000") @QueryParam("late6max") int late6max;
    @DefaultValue("360000000") @QueryParam("lone6min") int lone6min;
    @DefaultValue("360000000") @QueryParam("lone6max") int lone6max;
    
    // todo unimplemented parameters follow
    @QueryParam("limit") int limit;
    @QueryParam("trusted") List<String> trustedUserDataSources;
    @QueryParam("type") List<String> requestedTypes;

    /**
     * @return a positive text response when the server is alive
     */
    @GET
    @Produces("text/turtle")
    public Response query() {
        if (late6max < -90000000 || late6max > 90000000 ||
                late6min < -90000000 || late6min > 90000000 ||
                lone6max < -180000000 || lone6max > 180000000 ||
                lone6min < -180000000 || lone6min > 180000000 ) {
            return Response.status(Status.FORBIDDEN).type(MediaType.TEXT_PLAIN_TYPE).entity("All coordinate parameters are required; latitudes must be within -90e6 and 90e6, and longitudes within -180e6 and 180e6.").build();
        }
        
        if (late6max < late6min) {
            // swap the two
            late6min ^= late6max;
            late6max ^= late6min;
            late6min ^= late6max;
        }
        
        if (lone6max < lone6min) {
            // swap the two
            lone6min ^= lone6max;
            lone6max ^= lone6min;
            lone6min ^= lone6max;
        }
        
        // test at http://localhost:8080/ParkMe-server/availetc?late6min=52000000&lone6min=0&late6max=52100000&lone6max=100000
        try {
            final MyRepositoryModel repomodel = Config.openRepositoryModel(null);
            final StringBuilder sb = new StringBuilder("PREFIX geo-pos:<http://www.w3.org/2003/01/geo/wgs84_pos#>\n" +
                    "PREFIX lg:<http://linkedgeodata.org/ontology/>\n" +
                    "PREFIX omgeo: <http://www.ontotext.com/owlim/geo#>\n" +
                    "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n" +
                    "PREFIX xsd:<http://www.w3.org/2001/XMLSchema#>\n" +
                    "PREFIX park:<http://parking.kmi.open.ac.uk/todo/onto#>\n" +
                    "construct { ?s a lg:Parking; geo-pos:lat ?lat; geo-pos:long ?lon ; rdfs:label ?label; park:available \"true\"^^xsd:boolean. }\n" +
//                    "construct { ?s a lg:Parking; ?p ?o; park:available \"true\"^^xsd:boolean. }\n" +
                    "where {\n" +
                    "  ?s a lg:Parking; \n" +
                    "     omgeo:within(");
            sb.append(late6min/1e6);
            sb.append(' ');
            sb.append(lone6min/1e6);
            sb.append(' ');
            sb.append(late6max/1e6);
            sb.append(' ');
            sb.append(lone6max/1e6);
            sb.append(") . \n" +
                    "  optional { \n" +
                    "     ?s geo-pos:lat ?lat ; \n" +
                    "          geo-pos:long ?lon .  \n" +
                    "     optional { ?s rdfs:label ?label .}}}\n");
//                    "    optional { ?s ?p ?o. }}\n");
//            System.err.println(sb);
            final long time1 = System.currentTimeMillis();
            
//            final ClosableIterable<Statement> results = repomodel.sparqlConstruct(sb.toString());
            final GraphQueryResult graphQueryResult = repomodel.getConnection().prepareGraphQuery(
                    QueryLanguage.SPARQL, sb.toString()).evaluate();
            if (!graphQueryResult.hasNext()) {
                final long time2 = System.currentTimeMillis();
                System.err.println("PNEAR query " + late6min + " " + lone6min + " " + late6max + " " + lone6max + " took " + (time2-time1) + "ms and returned no results.");
                return Response.noContent().build();
            }
            
//            int i=0; Iterator<Statement> it = results.iterator();
//            while (it.hasNext()) { i++; it.next(); }
            
            StreamingOutput output = new StreamingOutput() {
                
                @Override
                public void write(OutputStream out) throws IOException {
                    try {
                        TurtleWriter writer = new TurtleWriter(out);
                        writer.startRDF();
                        
                        writer.handleNamespace("l", "http://linkedgeodata.org/triplify/");
                        writer.handleNamespace("s", "http://www.w3.org/2000/01/rdf-schema#");
                        writer.handleNamespace("g", "http://www.w3.org/2003/01/geo/wgs84_pos#");
                        writer.handleNamespace("d", "http://www.w3.org/2001/XMLSchema#");
                        writer.handleNamespace("p", "http://parking.kmi.open.ac.uk/todo/onto#");
                        writer.handleNamespace("o", "http://linkedgeodata.org/ontology/");
                        
                        int i=0; 
                        while (graphQueryResult.hasNext()) { 
                            i++; 
                            writer.handleStatement(graphQueryResult.next()); 
                        }
                        
                        writer.endRDF();
                        out.close();
    
                        Config.closeRepositoryModel(repomodel);
                        final long time2 = System.currentTimeMillis();
                        System.err.println("PNEAR query " + late6min + " " + lone6min + " " + late6max + " " + lone6max + " took " + (time2-time1) + "ms and returned " + i + " triples.");
                    } catch (Exception e) {
                        e.printStackTrace();
                        throw new IOException(e);
                    }
                }
            };
            
            return Response.ok(output).build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.serverError().type(MediaType.TEXT_PLAIN_TYPE).entity("Server error: " + e).build();
        }
    }
}
