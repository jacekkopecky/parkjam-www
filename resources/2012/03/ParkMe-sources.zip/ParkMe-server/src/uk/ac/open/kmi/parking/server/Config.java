package uk.ac.open.kmi.parking.server;

import javax.ws.rs.core.UriInfo;

import org.ontoware.rdf2go.exception.ModelRuntimeException;
import org.ontoware.rdf2go.model.node.URI;
import org.openrdf.rdf2go.RepositoryModel;
import org.openrdf.repository.Repository;
import org.openrdf.repository.RepositoryConnection;
import org.openrdf.repository.http.HTTPRepository;

/**
 * Configuration for the API, so far hardwired.
 * @author Jacek Kopecky
 *
 */
public final class Config {
    private Config() { 
        // instantiation forbidden
    }
    
    // manual configuration
    private static final String repositoryServerURI = "http://localhost:8080/openrdf-sesame";
    private static final String repositoryName = "tmp2";  // todo parking
    private static final HTTPRepository sesameRepository = new HTTPRepository(repositoryServerURI, repositoryName);
    
    private static final java.net.URI serverURI = java.net.URI.create("http://parking.kmi.open.ac.uk/data/"); 

    /**
     * creates and opens a model that attaches to the user management repository
     * @param context an optional URI for the repository context (subgraph), may be null
     * @return an open repository model
     */
    public static MyRepositoryModel openRepositoryModel(URI context) {
        MyRepositoryModel result = null;
        if (context == null) {
            result = new MyRepositoryModel(sesameRepository);
        } else {
            result = new MyRepositoryModel(context, sesameRepository);
        }
        result.open();
        return result;
    }
    
    /**
     * an extension of RepositoryModel that gives access to the underlying sesame repository connection
     */
    public static class MyRepositoryModel extends RepositoryModel {

        private static final long serialVersionUID = 1L;

        /**
         * @param repository repo
         * @throws ModelRuntimeException when something goes wrong
         */
        public MyRepositoryModel(Repository repository) throws ModelRuntimeException {
            super(repository);
        }
        
        /**
         * @param context context 
         * @param repository repo
         */
        public MyRepositoryModel(URI context, HTTPRepository repository) {
            super(context, repository);
        }
        
        /**
         * @return the underlying sesame repository connection, esp. useful for querying
         */
        public RepositoryConnection getConnection() {
            return this.connection;
        }
    }

    /**
     * close a model created by openRepositoryModel()
     * @param modelToClose the model to close
     */
    public static void closeRepositoryModel(RepositoryModel modelToClose) {
        modelToClose.close();
    }

    
    /**
     * returns the base URI for the application, so far hardwired
     * @param ctxt uri context
     * @return the base URI
     */
    public static java.net.URI getAppURI(UriInfo ctxt) {
        // todo this should come from ctxt.getBaseURI() but that currently returns localhost:8080 which isn't right
        return serverURI;
    }
}
