package uk.ac.open.kmi.parking.server;

import java.util.Date;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.CacheControl;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * @author Jacek Kopecky
 * Ping class, should return an uncachable positive text response when the server is alive.
 */
@Path("/ping")
public class PingResource {

    /**
     * @return a positive text response when the server is alive
     */
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public Response ping() {
        CacheControl cc = new CacheControl();
        cc.setNoCache(true);
        return Response.ok("server running " + new Date() + "\n").cacheControl(cc).build();
    }
}
