package uk.ac.open.kmi.parking.server;

import java.io.IOException;
import java.io.OutputStream;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;

import org.openrdf.model.Statement;
import org.openrdf.query.GraphQueryResult;
import org.openrdf.query.QueryLanguage;
import org.openrdf.rio.turtle.TurtleWriter;

import uk.ac.open.kmi.parking.server.Config.MyRepositoryModel;

/**
 * @author Jacek Kopecky
 * PARK resource, see deliverables (todo copy description here)
 */
@Path("/parks/{id}")
public class CarParkStaticInfoResource {
    @PathParam("id") String id;  // todo should be unnecessary if request URI is useful and used below 
    
    // todo we need all the car parks in the triple store to have .../parks/{id}#this IDs  - for now let's fudge it and do the last word as the ID, extracting from linkedgeodata.org URIs and putting in parking.kmi URIs
    
    /**
     * @return a positive text response when the server is alive
     */
    @GET
    @Produces("text/turtle")
    public Response query() {
        // test at http://localhost:8080/ParkMe-server/parks/1 or for now  http://localhost:8080/ParkMe-server/parks/way29869553 
        try {
            final MyRepositoryModel repomodel = Config.openRepositoryModel(null);

            // todo should be simply request URI or combined with http://parking.kmi.open.ac.uk/parks/ if request URI can get b0rked
            String uri = "http://linkedgeodata.org/triplify/" + this.id;

            final StringBuilder sb = new StringBuilder("construct { <");
            sb.append(uri);
            sb.append("> ?p ?o . }\n" +
                    "where {\n" +
                    "  <");
            sb.append(uri);
            sb.append("> ?p ?o . }\n");
//            System.err.println(sb);
            final long time1 = System.currentTimeMillis();
            
            final GraphQueryResult graphQueryResult = repomodel.getConnection().prepareGraphQuery(
                    QueryLanguage.SPARQL, sb.toString()).evaluate();
            if (!graphQueryResult.hasNext()) {
                final long time2 = System.currentTimeMillis();
                System.err.println("PARK query " + this.id + " took " + (time2-time1) + "ms and was not found.");
                return Response.status(404).type(MediaType.TEXT_PLAIN_TYPE).entity("Resource not known, perhaps a typo or an old link?").build();
            }
            
            StreamingOutput output = new StreamingOutput() {
                @Override
                public void write(OutputStream out) throws IOException {
                    try {
                        TurtleWriter writer = new TurtleWriter(out);
                        writer.startRDF();
                        
                        // todo these kinds of namespace lists should be in Onto.java
                        writer.handleNamespace("l", "http://linkedgeodata.org/triplify/");
                        writer.handleNamespace("s", "http://www.w3.org/2000/01/rdf-schema#");
                        writer.handleNamespace("g", "http://www.w3.org/2003/01/geo/wgs84_pos#");
                        writer.handleNamespace("G", "http://www.georss.org/georss/");
                        writer.handleNamespace("d", "http://www.w3.org/2001/XMLSchema#");
                        writer.handleNamespace("p", "http://parking.kmi.open.ac.uk/todo/onto#");
                        writer.handleNamespace("o", "http://linkedgeodata.org/ontology/");
                        writer.handleNamespace("x", "http://linkedgeodata.org/property/");
                        writer.handleNamespace("D", "http://purl.org/dc/terms/");
                        
                        int i=0; 
                        while (graphQueryResult.hasNext()) { 
                            i++; 
                            writer.handleStatement(graphQueryResult.next()); 
                        }
                        
                        // todo add link to /parks/{id}/avail&type=users
                        // todo add ratings
                        
                        writer.endRDF();
                        out.close();
    
                        Config.closeRepositoryModel(repomodel);
                        final long time2 = System.currentTimeMillis();
                        System.err.println("PARK query " + CarParkStaticInfoResource.this.id + " took " + (time2-time1) + "ms and returned " + i + " triples.");
                    } catch (Exception e) {
                        e.printStackTrace();
                        throw new IOException(e);
                    }
                }
            };
            
            return Response.ok(output).build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.serverError().type(MediaType.TEXT_PLAIN_TYPE).entity("Server error: " + e).build();
        }
    }
}
