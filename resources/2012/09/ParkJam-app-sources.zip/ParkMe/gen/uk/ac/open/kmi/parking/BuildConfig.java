/** Automatically generated file. DO NOT MODIFY */
package uk.ac.open.kmi.parking;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}