#data=read.csv(file.choose(), strip.white=TRUE, stringsAsFactors=FALSE)
#data=read.csv("/users/jk5837/work/cvs/ParkJam-simulation/r/outputs/output-0.csv", strip.white=TRUE, stringsAsFactors=FALSE)
#data=read.csv("/users/jk5837/work/cvs/ParkJam-simulation/r/outputs/output-01.csv", strip.white=TRUE, stringsAsFactors=FALSE)
data=read.csv("/users/jk5837/work/cvs/ParkJam-simulation/r/outputs/output-011.csv", strip.white=TRUE, stringsAsFactors=FALSE)
attach(data)


inrange <- function(v,r) { v >= r[1] & v<= r[2] }
mylowess <- function(...) { approx(do.call(cbind,lowess(...)), n=100) }
PC <- function(x) { sprintf("%1.0f%%", x*100) }
qpair <- function(a,b,centiles) { c(centiles[a+1], centiles[b+1]) }

centiles=quantile(cars, (0:100)/100)
intervals=rbind(qpair(67,87,centiles), qpair(47,67,centiles), qpair(0,20,centiles))
intervals.len = nrow(intervals)
capacity=capacity[1]

actPJCarsPC=actPJCars/cars*100
actWebCarsPC=actWebCars/cars*100
actPJCars.nonzero = actPJCars; actPJCars.nonzero[actPJCars==0]<-1
actPJCPC=actPJC/actPJCars.nonzero*100
carsPC=cars/capacity*100



#cor.test(actPJCarsPC, cars)
#cor.test(cars, driven)
#cor.test(actPJCarsPC, driven)




dev.new(title="plot1", width=5.35, height=4.95)
plot1=dev.cur()
dev.new(title="plot2", width=5.35, height=4.95)
plot2=dev.cur()
dev.new(title="plot3", width=5.35, height=4.95)
plot3=dev.cur()
dev.new(title="plot4", width=5.35, height=4.95)
plot4=dev.cur()

dev.set(plot1)
plot(1, type="n", xlim=c(min(actPJCarsPC+actWebCarsPC),max(actPJCarsPC+actWebCarsPC)), ylim=c(480,900), ann=FALSE, xaxt="n", yaxt="n")
xpos <- seq(0, 60, by=10)
axis(1, at=xpos, labels=sprintf("%2.0f%%", xpos))
ypos <- seq(500, 900, by=100)
axis(2, at=ypos, labels=sprintf("%3.0fm", ypos))
title(main="General benefit of ParkJam")
title(xlab="Proportion of ParkJam users among all cars")
title(ylab="Distance driven (average by car)")
for (i in 0:(65/10)) abline(v=i*10, col="grey", lty="dotted", lwd=.5)
for (i in seq(500,900, by=50)) abline(h=i, col="grey", lty="dotted", lwd=.5)
titles=c()
colors=c()
ltys=c()
colorbase=1
for (i in 1:intervals.len) {
  interval=intervals[i,]
  carselection=inrange(cars,interval)&security
  tmpmatrix=cbind((actWebCarsPC+actPJCarsPC)[carselection], driven[carselection])
  lines(mylowess(tmpmatrix, f=.1), col=colorbase+i, lty="solid"); 
  titles<-append(titles, paste0(PC(mean(interval)/capacity), "C, smooth")); colors<-append(colors, colorbase+i); ltys<-append(ltys, "solid"); 
}
for (i in 1:intervals.len) {
  interval=intervals[i,]
  carselection=inrange(cars,interval)&security
  lmx<-lm(driven[carselection] ~ (actPJCarsPC+actWebCarsPC)[carselection])
  abline(lmx, col=colorbase+i, lty="dashed")
  titles<-append(titles, paste0(PC(mean(interval)/capacity), "C, trend")); colors<-append(colors, colorbase+i); ltys<-append(ltys, "dashed"); 
}
for (i in 1:intervals.len) {
  interval=intervals[i,]
  carselection=inrange(cars,interval)&security
  tmpmatrix=cbind((actWebCarsPC+actPJCarsPC)[carselection], drivenN[carselection])
  lines(mylowess(tmpmatrix, f=.1), col=colorbase+i, lty="dotted"); 
  titles<-append(titles, paste0(PC(mean(interval)/capacity), "C, no-PJ")); colors<-append(colors, colorbase+i); ltys<-append(ltys, "dotted"); 
}
legend(62.5, 900, titles, col=colors, lty=ltys, ncol=3, xjust=1, bg="white", cex=0.7)

dev.set(plot2)
plot(1, type="n", xlim=c(min(actPJCarsPC,actWebCarsPC),max(actPJCarsPC,actWebCarsPC)), ylim=c(480,900), ann=FALSE, xaxt="n", yaxt="n")
xpos <- seq(0, 30, by=10)
axis(1, at=xpos, labels=sprintf("%2.0f%%", xpos))
ypos <- seq(500, 900, by=100)
axis(2, at=ypos, labels=sprintf("%3.0fm", ypos))
title(main="Benefit of using ParkJam at home vs. in car")
title(xlab="Proportion of ParkJam users (either at home or in car)")
title(ylab="Distance driven (average by car)")
for (i in seq(0,35, by=5)) abline(v=i, col="grey", lty="dotted", lwd=.5)
for (i in seq(500,900, by=50)) abline(h=i, col="grey", lty="dotted", lwd=.5)
titles=c()
colors=c()
ltys=c()
colorbase=1
for (i in 1:intervals.len) {
  interval=intervals[i,]
  carselection=inrange(cars,interval)&security
  tmpmatrix=cbind((actWebCarsPC)[carselection], driven[carselection])
  lines(mylowess(tmpmatrix, f=.1), col=colorbase+i, lty="solid")
  titles<-append(titles, paste0(PC(mean(interval)/capacity), "C, @home")); colors<-append(colors, colorbase+i); ltys<-append(ltys, "solid"); 
}
for (i in 1:intervals.len) {
  interval=intervals[i,]
  carselection=inrange(cars,interval)&security
  tmpmatrix=cbind((actPJCarsPC)[carselection], driven[carselection])
  lines(mylowess(tmpmatrix, f=.1), col=colorbase+i, lty="dashed")
  titles<-append(titles, paste0(PC(mean(interval)/capacity), "C, in car")); colors<-append(colors, colorbase+i); ltys<-append(ltys, "dashed"); 
}
colorbase=4
for (i in 1:intervals.len) {
  interval=intervals[i,]
  carselection=inrange(cars,interval)&security&actPJCarsPC<3
  tmpmatrix=cbind((actWebCarsPC)[carselection], driven[carselection])
  lines(mylowess(tmpmatrix, f=.1), col=colorbase+i, lty="solid")
  titles<-append(titles, paste0(PC(mean(interval)/capacity), "C, @home (<3% in car)")); colors<-append(colors, colorbase+i); ltys<-append(ltys, "solid"); 
}
for (i in 1:intervals.len) {
  interval=intervals[i,]
  carselection=inrange(cars,interval)&security&actWebCarsPC<3
  tmpmatrix=cbind((actPJCarsPC)[carselection], driven[carselection])
  lines(mylowess(tmpmatrix, f=.1), col=colorbase+i, lty="dashed")
  titles<-append(titles, paste0(PC(mean(interval)/capacity), "C, in car (<3% @home)")); colors<-append(colors, colorbase+i); ltys<-append(ltys, "dashed"); 
}
legend(35, 900, titles, col=colors, lty=ltys, ncol=2, xjust=1, bg="white", cex=0.6)

dev.set(plot3)
plot(1, type="n", xlim=c(min(actPJCarsPC+actWebCarsPC),max(actPJCarsPC+actWebCarsPC)), ylim=c(480,900), ann=FALSE, xaxt="n", yaxt="n")
xpos <- seq(0, 60, by=10)
axis(1, at=xpos, labels=sprintf("%2.0f%%", xpos))
ypos <- seq(500, 900, by=100)
axis(2, at=ypos, labels=sprintf("%3.0fm", ypos))
title(main="Benefit of increased proportion of contributors")
title(xlab="Proportion of ParkJam users among all cars")
title(ylab="Distance driven (average by car)")
for (i in 0:(65/10)) abline(v=i*10, col="grey", lty="dotted", lwd=.5)
for (i in seq(500,900, by=50)) abline(h=i, col="grey", lty="dotted", lwd=.5)
titles=c()
colors=c()
ltys=c()
pchs=c()
colorbase=2
pchbase=0
pointbase=10
for (i in 1:intervals.len) {
  interval=intervals[i,]
  carselection=inrange(cars,interval)&!security&actPJCPC<10
  tmpmatrix=cbind((actWebCarsPC+actPJCarsPC)[carselection], driven[carselection])
  mlw=mylowess(tmpmatrix, f=.1)
  color=colorbase
  lty="solid"
  lines(mlw, col=color, lty=lty)
  pch=pchbase+i
  points(approx(mlw, xout=0:1*25+pointbase), pch=pch, col=color)
  titles<-append(titles, paste0(PC(mean(interval)/capacity), "C, !sec, con<10")); colors<-append(colors, color); ltys<-append(ltys, lty); pchs<-append(pchs, pch);
}
colorbase=3
pointbase=pointbase+5
for (i in 1:intervals.len) {
  interval=intervals[i,]
  carselection=inrange(cars,interval)&!security&inrange(actPJCPC, c(10,20))
  tmpmatrix=cbind((actWebCarsPC+actPJCarsPC)[carselection], driven[carselection])
  mlw=mylowess(tmpmatrix, f=.1)
  color=colorbase
  lty="solid"
  lines(mlw, col=color, lty=lty); 
  pch=pchbase+i
  points(approx(mlw, xout=0:1*25+pointbase), pch=pch, col=color)
  titles<-append(titles, paste0(PC(mean(interval)/capacity), "C, !sec, 10<con<20")); colors<-append(colors, color); ltys<-append(ltys, lty); pchs<-append(pchs, pch);
}
colorbase=4
pointbase=pointbase+5
for (i in 1:intervals.len) {
  interval=intervals[i,]
  carselection=inrange(cars,interval)&!security&inrange(actPJCPC, c(25,35))
  tmpmatrix=cbind((actWebCarsPC+actPJCarsPC)[carselection], driven[carselection])
  mlw=mylowess(tmpmatrix, f=.1)
  color=colorbase
  lty="solid"
  lines(mlw, col=color, lty=lty); 
  pch=pchbase+i
  points(approx(mlw, xout=0:1*25+pointbase), pch=pch, col=color)
  titles<-append(titles, paste0(PC(mean(interval)/capacity), "C, !sec, 25<con<35")); colors<-append(colors, color); ltys<-append(ltys, lty);  pchs<-append(pchs, pch);
}
pointbase=pointbase+5
for (i in 1:intervals.len) {
  interval=intervals[i,]
  carselection=inrange(cars,interval)&security&actPJCPC==0
  tmpmatrix=cbind((actWebCarsPC+actPJCarsPC)[carselection], driven[carselection])
  mlw=mylowess(tmpmatrix, f=.1)
  lty="dotted"
  color="black"
  lines(mlw, col=color, lty=lty); 
  pch=pchbase+i
  points(approx(mlw, xout=0:1*25+pointbase), pch=pch, col=color)
  titles<-append(titles, paste0(PC(mean(interval)/capacity), "C, sec, !con")); colors<-append(colors, color); ltys<-append(ltys, lty);  pchs<-append(pchs, pch);
}
legend(62.5, 900, titles, col=colors, pch=pchs, lty=ltys, ncol=2, xjust=1, bg="white", cex=0.6)

dev.set(plot4)
plot(1, type="n", xlim=c(min(carsPC),max(carsPC)), ylim=c(480,900), ann=FALSE, xaxt="n", yaxt="n")
xpos <- seq(70, 100, by=5)
axis(1, at=xpos, labels=sprintf("%2.0f%%", xpos))
ypos <- seq(500, 900, by=100)
axis(2, at=ypos, labels=sprintf("%3.0fm", ypos))
title(main="Benefit for different types of users")
title(xlab="Total occupancy")
title(ylab="Distance driven (average by car)")
for (i in xpos) abline(v=i, col="grey", lty="dotted", lwd=.5)
for (i in seq(500,900, by=50)) abline(h=i, col="grey", lty="dotted", lwd=.5)
titles=c()
colors=c()
ltys=c()
pchs=c()
color=1
pch=1
pointbase=3
{
  carselection=security&!is.na(drivenN)
  tmpmatrix=cbind(carsPC[carselection], drivenN[carselection])
  mlw=mylowess(tmpmatrix, f=.1)
  lty="solid"
  lines(mlw, col=color, lty=lty)
  points(approx(mlw, xout=c(70,80,90)+pointbase), pch=pch, col=color)
  titles<-append(titles, "cars w/o ParkJam"); colors<-append(colors, color); ltys<-append(ltys, lty); pchs<-append(pchs, pch);
}
#   color=color+1
#   pch=pch+1
#   pointbase=pointbase+1
#   {
#     carselection=!security&!is.na(drivenN)
#     tmpmatrix=cbind(carsPC[carselection], drivenN[carselection])
#     mlw=mylowess(tmpmatrix, f=.1)
#     lty="solid"
#     lines(mlw, col=color, lty=lty)
#     points(approx(mlw, xout=c(70,80,90)+pointbase), pch=pch, col=color)
#     titles<-append(titles, "cars w/o ParkJam2"); colors<-append(colors, color); ltys<-append(ltys, lty); pchs<-append(pchs, pch);
#   }
#   color=color+1
#   pch=pch+1
#   pointbase=pointbase+1
#   {
#     carselection=!security&actPJC==0
#     tmpmatrix=cbind(carsPC[carselection], driven[carselection])
#     mlw=mylowess(tmpmatrix, f=.1)
#     lty="solid"
#     lines(mlw, col=color, lty=lty)
#     points(approx(mlw, xout=c(70,80,90)+pointbase), pch=pch, col=color)
#     titles<-append(titles, "cars w/o ParkJam3"); colors<-append(colors, color); ltys<-append(ltys, lty); pchs<-append(pchs, pch);
#   }
color=color+1
pch=pch+1
pointbase=pointbase+1
{
  carselection=security&!is.na(drivenPJF)
  tmpmatrix=cbind(carsPC[carselection], drivenPJF[carselection])
  mlw=mylowess(tmpmatrix, f=.1)
  lty="solid"
  lines(mlw, col=color, lty=lty)
  points(approx(mlw, xout=c(70,80,90)+pointbase), pch=pch, col=color)
  titles<-append(titles, "PJF cars"); colors<-append(colors, color); ltys<-append(ltys, lty); pchs<-append(pchs, pch);
}
color=color+1
pch=pch+1
pointbase=pointbase+1
{
  carselection=security&!is.na(drivenWeb)
  tmpmatrix=cbind(carsPC[carselection], drivenWeb[carselection])
  mlw=mylowess(tmpmatrix, f=.1)
  lty="solid"
  lines(mlw, col=color, lty=lty)
  points(approx(mlw, xout=c(70,80,90)+pointbase), pch=pch, col=color)
  titles<-append(titles, "home users"); colors<-append(colors, color); ltys<-append(ltys, lty); pchs<-append(pchs, pch);
}
color=color+1
pch=pch+1
pointbase=pointbase+1
{
  carselection=security&!is.na(drivenPJ)
  tmpmatrix=cbind(carsPC[carselection], drivenPJ[carselection])
  mlw=mylowess(tmpmatrix, f=.1)
  lty="solid"
  lines(mlw, col=color, lty=lty)
  points(approx(mlw, xout=c(70,80,90)+pointbase), pch=pch, col=color)
  titles<-append(titles, "cars w/ParkJam"); colors<-append(colors, color); ltys<-append(ltys, lty); pchs<-append(pchs, pch);
}
color=color+1
pch=pch+1
pointbase=pointbase+1
{
  carselection=security&!is.na(drivenPJFB)
  tmpmatrix=cbind(carsPC[carselection], drivenPJFB[carselection])
  mlw=mylowess(tmpmatrix, f=.1)
  lty="solid"
  lines(mlw, col=color, lty=lty)
  points(approx(mlw, xout=c(70,80,90)+pointbase), pch=pch, col=color)
  titles<-append(titles, "PJFB cars"); colors<-append(colors, color); ltys<-append(ltys, lty); pchs<-append(pchs, pch);
}
color=color+1
pch=pch+1
pointbase=pointbase+1
{
  carselection=security&!is.na(drivenPJW)
  tmpmatrix=cbind(carsPC[carselection], drivenPJW[carselection])
  mlw=mylowess(tmpmatrix, f=.1)
  lty="solid"
  lines(mlw, col=color, lty=lty)
  points(approx(mlw, xout=c(70,80,90)+pointbase), pch=pch, col=color)
  titles<-append(titles, "PJW cars"); colors<-append(colors, color); ltys<-append(ltys, lty); pchs<-append(pchs, pch);
}
legend(70, 900, titles, col=colors, pch=pchs, lty=ltys, xjust=0, bg="white", cex=0.7)

