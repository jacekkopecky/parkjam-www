package uk.ac.open.kmi.parking.simulation;

import java.util.HashSet;
import java.util.Set;

/**
 * this is an NO or NP (normal optimistic or pessimistic) car park.
 * has a preference list of car parks where it wants to park; may also be "pessimistic" which means it knows the expected times when car parks are usually already full and doesn't bother to go there then
 */
class Car extends SimulationElement {
    private double distanceDriven = 0;
    private int countFailedParkings = 0;
    final Node nodeOfEntry;
    final int timeOfEntry;
    private int timeOfParking = -1;
    final CarPark[] preference;
    protected int preferencePosition = 0;
    private boolean contributing;

    protected final Set<CarPark> experiencedFullCarparks = new HashSet<CarPark>();

    boolean pessimistic = false;

    private static final int PESSIMIST_KNOWN_CARPARKS = 5;

    Car(Node entry, int time, CarPark[] pref, boolean pessimist, Simulation sim) {
        super(sim);
        this.nodeOfEntry = entry;
        this.timeOfEntry = time;
        this.preference = pref;
        this.id = nextID++;
        this.pessimistic = pessimist;
        this.contributing = false;
    }

    protected Car(Node entry, int time, CarPark[] pref, boolean pessimist, boolean contributing, Simulation sim) {
        this(entry, time, pref, pessimist, sim);
        this.contributing = contributing;
    }

    CarPark getCurrentTargetCarpark() {
        return this.preference[this.preferencePosition];
    }

    protected boolean shouldSkipCurrentCarparkOnEntry() {
        return this.pessimistic && this.preferencePosition < PESSIMIST_KNOWN_CARPARKS && this.preference[this.preferencePosition].getExpectedFullTime() < this.sim.currentTime;
    }

    protected boolean shouldSkipCurrentCarparkOnFailedParking() {
        return this.experiencedFullCarparks.contains(this.preference[this.preferencePosition]) ||
                this.pessimistic && this.preferencePosition < PESSIMIST_KNOWN_CARPARKS && this.preference[this.preferencePosition].getExpectedFullTime() < this.sim.currentTime;
    }

    protected boolean shouldSkipCurrentCarparkEnRoute() {
        return false;
    }

    private void skipCarparksOnEntry() {
        while (shouldSkipCurrentCarparkOnEntry()) {
            skipCurrentCarpark();
        }
    }

    private void skipCarparksOnFailedParking() {
        while (shouldSkipCurrentCarparkOnFailedParking()) {
            skipCurrentCarpark();
        }
    }

    private void skipCarparksEnRoute() {
        while (shouldSkipCurrentCarparkEnRoute()) {
            skipCurrentCarpark();
        }
    }

    private void skipCurrentCarpark() {
        this.preferencePosition++;
        if (this.preferencePosition >= this.preference.length) {
            this.pessimistic = false;
            this.preferencePosition = 0;
            // todo count times that a pessimistic car park has become optimistic
            // todo maybe model calling security?
            System.out.print("x");
        }
    }

    final void go() {
        skipCarparksOnEntry();
        this.nodeOfEntry.addCar(this);
    }

    final void enteringNewNode() {
        skipCarparksEnRoute();
    }

    final void parkNow() {
        assert this.timeOfParking == -1 : "parking a car after it's been parked!";
        this.timeOfParking = this.sim.currentTime;
        this.sim.parkedCars.add(this);
        this.sim.activeCars.remove(this);
    }

    int getTimeSpentParking() {
        return this.timeOfParking - this.timeOfEntry;
    }

    final void handleFailedParking(CarPark park) {
        assert park == this.preference[this.preferencePosition] : "parking at an unexpected car park!";
        this.countFailedParkings++;
        this.experiencedFullCarparks.add(park);
        if (this.contributing && !park.isParkJamFull()) {
            park.setParkjamFull();
            this.sim.totalDriverContributions++;
//            System.out.print('c'); // todo count this
        }

        skipCarparksOnFailedParking();
    }

    final void addTraveled(double length) {
        this.distanceDriven += length;
    }

    final double getDistanceDriven() {
        return this.distanceDriven;
    }

    final int getFailedParkings() {
        return this.countFailedParkings;
    }

    private int id;
    private static int nextID = 0;

    @Override
    public String toString() {
        return "Car " + this.id;
    }
}
