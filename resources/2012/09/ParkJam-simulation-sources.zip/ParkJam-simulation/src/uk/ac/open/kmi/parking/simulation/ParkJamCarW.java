package uk.ac.open.kmi.parking.simulation;

/**
 * checks ParkJam while trying to park; W just watches, C also contributes when it fails to park
 */
class ParkJamCarW extends Car {
    ParkJamCarW(Node entry, int time, CarPark[] pref, boolean pessimist, boolean contributing, Simulation sim) {
        super(entry, time, pref, pessimist, contributing, sim);
    }

    @Override
    protected boolean shouldSkipCurrentCarparkOnEntry() {
        return super.shouldSkipCurrentCarparkOnEntry() || this.preference[this.preferencePosition].isParkJamFull();
    }

    @Override
    protected boolean shouldSkipCurrentCarparkOnFailedParking() {
        return super.shouldSkipCurrentCarparkOnFailedParking() || this.preference[this.preferencePosition].isParkJamFull();
    }

    @Override
    protected boolean shouldSkipCurrentCarparkEnRoute() {
        return this.experiencedFullCarparks.contains(this.preference[this.preferencePosition]) ||
                this.preference[this.preferencePosition].isParkJamFull();
    }

}
