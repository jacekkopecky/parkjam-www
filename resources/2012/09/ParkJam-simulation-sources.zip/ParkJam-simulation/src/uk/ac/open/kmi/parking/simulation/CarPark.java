package uk.ac.open.kmi.parking.simulation;

import java.util.HashMap;
import java.util.Map;

class CarPark extends SimulationElement {
    private int capacity;
    private int occupancy = 0;
    private int fullTime;
    private int expectedFullTime;
    private int parkjamFullTime = Integer.MAX_VALUE;
    private Map<Node, Road> roadsInLieuOfFailure = new HashMap<Node, Road>();

    CarPark(int cap, String id, int expectedFullTime, Simulation sim) {
        super(sim);
        this.capacity = cap;
        this.id = id;
        this.expectedFullTime = expectedFullTime;
    }

    int getExpectedFullTime() {
        return this.expectedFullTime;
    }

    void addRoadInLieuOfFailure(Road r) {
        this.roadsInLieuOfFailure.put(r.getStart(), r);
    }

    int getCapacity() {
        return this.capacity;
    }

    void addCar(Car car, Node arrivalNode) {
        if (this.occupancy < this.capacity) {
            // put it in parkedCars and remove from activeCars, setting car properties appropriately
            this.occupancy++;
            car.parkNow();
            if (this.occupancy == this.capacity) {
                this.fullTime = this.sim.currentTime;
            }
        } else {
            // or put it in its internal road (depending on the arrival node), updating car properties appropriately
            Road rd = this.roadsInLieuOfFailure.get(arrivalNode);
            rd.addCar(car);
            car.handleFailedParking(this);
        }

    }

    private String id;

    @Override
    public String toString() {
        return "Car park " + this.id;
    }

    public String getID() {
        return this.id;
    }

    public int getTimeOfBecomingFull() {
        return isFull() ? this.fullTime : -1;
    }

    public boolean isFull() {
        return this.occupancy >= this.capacity;
    }

    public boolean isParkJamFull() {
        return this.parkjamFullTime < Integer.MAX_VALUE;
    }

    public int getParkJamFullTime() {
        return this.parkjamFullTime;
    }

    public void setParkjamFull() {
        assert !this.isParkJamFull() : "cannot set parkjam full repeatedly";
        assert this.isFull() : "cannot set parkjam full before the car park fills up";
        this.parkjamFullTime = this.sim.currentTime;
    }
}
