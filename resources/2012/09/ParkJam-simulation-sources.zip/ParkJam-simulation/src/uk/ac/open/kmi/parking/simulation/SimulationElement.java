package uk.ac.open.kmi.parking.simulation;

abstract class SimulationElement {
    protected final Simulation sim;

    protected SimulationElement(Simulation sim) {
        this.sim = sim;
    }

}
