package uk.ac.open.kmi.parking.simulation;

/**
 * checks ParkJam *before* setting out (or rather, when deciding where to park, checks that the car park was marked as full already when the car was setting out)
 */
class ParkJamCarBF extends Car {
    final int timeLeftHome;
    final boolean isB;
    final boolean isF;

    private ParkJamCarBF(Node entry, int time, CarPark[] pref, boolean pessimist, int timeLeftHome, boolean f, boolean contributing, Simulation sim) {
        super(entry, time, pref, pessimist, contributing, sim);
        this.timeLeftHome = timeLeftHome;
        this.isB = timeLeftHome != Integer.MAX_VALUE;
        this.isF = f;
    }

    static Car createCarB(Node entry, int time, CarPark[] pref, boolean pessimist, int timeLeftHome, Simulation sim) {
        return new ParkJamCarBF(entry, time, pref, pessimist, timeLeftHome, false, false, sim);
    }

    static Car createCarF(Node entry, int time, CarPark[] pref, boolean pessimist, boolean contributing, Simulation sim) {
        return new ParkJamCarBF(entry, time, pref, pessimist, Integer.MAX_VALUE, true, contributing, sim);
    }

    static Car createCarBF(Node entry, int time, CarPark[] pref, boolean pessimist, int timeLeftHome, boolean contributing, Simulation sim) {
        return new ParkJamCarBF(entry, time, pref, pessimist, timeLeftHome, true, contributing, sim);
    }

    @Override
    protected boolean shouldSkipCurrentCarparkOnEntry() {
        if (super.shouldSkipCurrentCarparkOnEntry()) {
            return true;
        }

        return this.isB && this.preference[this.preferencePosition].getParkJamFullTime() < this.timeLeftHome;
    }

    @Override
    protected boolean shouldSkipCurrentCarparkOnFailedParking() {
        if (super.shouldSkipCurrentCarparkOnFailedParking()) {
            return true;
        }

        if (this.isF) {
            return this.preference[this.preferencePosition].isParkJamFull();
        } else {
            return this.preference[this.preferencePosition].getParkJamFullTime() < this.timeLeftHome;
        }
    }
}
