package uk.ac.open.kmi.parking.simulation;

import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * simulation of car parking
 * @author Jacek Kopecky
 *
 * todo do some per-pref analysis to see if the preferences make sense
 */
public class Simulation implements Runnable {

    private final static int DURATION = 6*60*60;  // 6h duration of simulation, in seconds, with normal arrival distribution centered in the middle with 1h standard deviation
    private final static double SIGMAS = 3.5;

    private final static int TOTAL_CAPACITY = 1699;

    private final static int AVERAGE_COMMUTE = 15*60; // todo most people live around 15min away, sigma same 15min

    private final static int SECURITY_CHECK_INTERVAL = 30*60; // security checks the car parks every 30mins

    final static PrintStream out;
    static {
        PrintStream out2;
        try {
            String filename = "output-" + System.currentTimeMillis()/1000 + ".csv";
            System.out.println("output: " + filename);
            out2 = new PrintStream(filename);
        } catch (IOException e) {
            System.err.println("cannot open output file");
            out2 = System.out;
        }
        out = out2;
    }

    static int random(int min, int max) {
        return rand.nextInt(max-min+1) + min;
    }

    /**
     * runs the simulation
     * @param args ignored at the moment
     * @throws Exception in case
     */
    public static void main(String[] args) throws Exception {

        long caseno = 0;
        long firstTime = System.currentTimeMillis();
        long lastTime = firstTime;

        printHeaders();

        while (true) {
            int ncars = random(70*TOTAL_CAPACITY/100, TOTAL_CAPACITY);
            int pessimistPercent = random(50, 100);
            boolean security = rand.nextBoolean();
            int parkJamWebViewPercent = random(0, 30);
            int parkJamCarsPercent = random(0, 30);
            int parkJamWPercent = random(0, 50);
            int parkJamBPercent = random(0, 100);
            int parkJamContributingPercent = random(0, 50);

            Simulation sim = new Simulation(ncars, pessimistPercent, security, parkJamWebViewPercent, parkJamCarsPercent, parkJamWPercent, parkJamBPercent, parkJamContributingPercent);
            sim.run();

            printStats(sim);

            if (++caseno % 1000 == 0) {
                System.out.println("case " + caseno + ", time: " + (-lastTime + (lastTime=System.currentTimeMillis()))/1000 + "s, total " + (lastTime - firstTime)/1000 + "s");
                System.gc();
            }

        }
    }

    private static double defaultZero(double d) {
        return Double.isInfinite(d) || Double.isNaN(d) ? 0 : d;
    }

    private static void printHeaders() {
        out.print("capacity, speedmph, cars, pess, actPess, security, webCars, actWebCars, pjCars, actPJCars,  pjW, actPJW,  pjB, actPJB,  pjC, actPJC, ");
        out.print("driven, parktime, dissatisfied, pjDriverReports, secnoticed, seclate, seclate_s, failpark, failmax, ");
        for (C type : C.values()) {
            if (type == C.ALL) continue;
            out.printf("driven%1$s, parktime%1$s, dissatisfied%1$s, failpark%1$s, failmax%1$s, ", typeName[type.ordinal()]);
        }
        out.print("cp0FullTime, cp1FullTime, cp2FullTime, cp3FullTime, cp4FullTime, cp5FullTime, cp6FullTime, cp7FullTime, cp8FullTime, cp9FullTime");
        out.println();
    }

    private static void printStats(Simulation sim) {
        // todo also show results for parkjammed cars vs non-parkjammed cars

        if (!sim.success) {
            System.out.println("skipping failed simulation");
            return;
        }
        out.printf("%8d, ", TOTAL_CAPACITY);
        out.printf("%8.1f, ", Road.SPEED_MPH); // todo make half, check that it doesn't affect meters driven
        out.printf("%4d, ", sim.numberOfCars);
        out.printf("%4d, ", sim.percentPessimists*sim.numberOfCars/100);
        out.printf("%7d, ", sim.actualPessimists);
        out.printf("%8s, ", String.valueOf(sim.hasSecurity).toUpperCase());
        out.printf("%7d, ", sim.percentParkJamWebView*sim.numberOfCars/100);
        out.printf("%10d, ", sim.actualWebViewCars);
        out.printf("%6d, ", sim.percentParkJamCars*sim.numberOfCars/100);
        out.printf("%9d, ", sim.actualParkJamCars);

        out.printf("%4d, ", sim.percentParkJamW*sim.percentParkJamCars*sim.numberOfCars/10000);
        out.printf("%6d, ", sim.actualParkJamWCars);
        out.printf("%4d, ", sim.percentParkJamB*(100-sim.percentParkJamW)*sim.percentParkJamCars*sim.numberOfCars/1000000); // barely not overflowing
        out.printf("%6d, ", sim.actualParkJamBFCars);
        out.printf("%4d, ", sim.percentParkJamContributing*sim.percentParkJamCars*sim.numberOfCars/10000);
        out.printf("%6d, ", sim.actualParkJamContributingCars);

        out.printf("%6.0f, ", sim.totalDistanceDriven[C.ALL.ordinal()] / sim.numberOfCars);
        out.printf("%8d, ", sim.totalTimeParking[C.ALL.ordinal()] / sim.numberOfCars);
        out.printf("%12d, ", sim.totalCarsThatFailedParking[C.ALL.ordinal()]);
        out.printf("%15d, ", sim.totalDriverContributions);
        out.printf("%10d, ", sim.countNoticedBySecurity);
        out.printf("%7d, ", sim.countDriverReportsBeatSecurity);
        out.printf("%9.0f, ", defaultZero(sim.totalTimeDriverReportsBeatSecurity / 1.0 / sim.countDriverReportsBeatSecurity));
        out.printf("%8d, ", sim.totalFailedParkings[C.ALL.ordinal()]);
        out.printf("%7d", sim.maxFailedParkings[C.ALL.ordinal()]);

        for (C type : C.values()) {
            if (type == C.ALL) continue;
            out.printf(", %" + (6 + typeName[type.ordinal()].length()) + ".0f", sim.totalDistanceDriven[type.ordinal()] / sim.countCars[type.ordinal()]);
            out.printf(", %" + (8 + typeName[type.ordinal()].length()) + ".0f", sim.totalTimeParking[type.ordinal()] / 1.0 / sim.countCars[type.ordinal()]);
            out.printf(", %" + (12+ typeName[type.ordinal()].length()) + "d", sim.totalCarsThatFailedParking[type.ordinal()]);
            out.printf(", %" + (8 + typeName[type.ordinal()].length()) + "d", sim.totalFailedParkings[type.ordinal()]);
            out.printf(", %" + (7 + typeName[type.ordinal()].length()) + "d", sim.maxFailedParkings[type.ordinal()]);
        }

        for (CarPark cp : sim.carparks) {
            out.printf(", %11d", cp.getTimeOfBecomingFull());
        }
        out.println();
    }

    @Override
    public void run() {
//        out.print(".");
        go();
        computeStats();
    }


    final int numberOfCars;
    final int percentPessimists;
    final int percentParkJamWebView;
    final int percentParkJamCars;
    final int percentParkJamW;
    final int percentParkJamB;
    final int percentParkJamContributing;
    final boolean hasSecurity;

    final List<CarPark> carparks = new ArrayList<CarPark>();
    final List<Node> nodes = new ArrayList<Node>();
    final List<Preference> prefs = new ArrayList<Preference>();
    final List<Road> roads = new ArrayList<Road>();
    List<Car> parkedCars;
    List<Car> newCars;
    Set<Car> activeCars;
    int currentTime = 0;

    private boolean initialized = false;

    private Simulation(int number, int percent, boolean security, int parkJamWebViewPercent, int parkJamCarsPercent, int parkJamWPercent, int parkJamBPercent, int parkJamContributingPercent) {
        this.numberOfCars = number;
        this.percentPessimists = percent;
        this.percentParkJamB = parkJamBPercent;
        this.percentParkJamCars = parkJamCarsPercent;
        this.percentParkJamContributing = parkJamContributingPercent;
        this.percentParkJamW = parkJamWPercent;
        this.percentParkJamWebView = parkJamWebViewPercent;
        this.hasSecurity = security;
    }
        // initialize car parks with their sizes

    void initialize() {
        assert !this.initialized : "already initialized";

        this.initialized = true;
        initializeModel();
        int totalCapacity = 0;
        for (CarPark p : this.carparks) {
            totalCapacity += p.getCapacity();
        }

        assert totalCapacity == TOTAL_CAPACITY : "total capacity doesn't match: got " + totalCapacity + " and expected " + TOTAL_CAPACITY;

        if (totalCapacity < this.numberOfCars) {
            System.err.println("too many cars, won't simulate over capacity " + totalCapacity);
            return;
        }

        this.parkedCars = new ArrayList<Car>(this.numberOfCars);
        this.newCars = generateCars();
        this.activeCars = new HashSet<Car>(this.newCars);

        Collections.sort(this.newCars, new Comparator<Car>() {
            @Override
            public int compare(Car c0, Car c1) {
                return c0.timeOfEntry - c1.timeOfEntry;
            }
        });

    }

    private void go() {
        if (!this.initialized) {
            initialize();
        }
        assert !this.done : "cannot run the simulation multiple times";

        this.done = true;

        while (!this.activeCars.isEmpty()) {
            // put cars that are appearing now into the road system in their respective entry nodes
            while (!this.newCars.isEmpty() && this.newCars.get(0).timeOfEntry <= this.currentTime) {
                this.newCars.remove(0).go();
            }

            // for each road - let the road progress its cars,
            for (Road r : this.roads) {
                r.progress();
            }

            // for each node - handle the cars waiting here
            for (Node n : this.nodes) {
                n.handleWaitingCars();
            }

            // let security check car parks
            doSecurityParkjamCheck();

            // todo check what would happen if vandals sabotage the system
            // one can be random submissions
            // another can indicate that all is available
            // yet another can indicate that all is full
            // letVandalsLoose();

            // every some time, write out statistics?

            this.currentTime++;
//            if (currentTime % 1000 == 0) {
//                out.println("current time " + currentTime + " new cars " + newCars.size() + " active cars " + activeCars.size() + " parked cars " + parkedCars.size());
//            }

            if (this.currentTime > 40000) {
                System.out.println("too much time passed, giving up");
                return;
            }
        }
        this.success = true;
    }

    boolean done = false;
    boolean success = false;

    private int nextSecurityCheckTime = -1;
    private Set<CarPark> securityNoticedFull = new HashSet<CarPark>();
    private int totalTimeDriverReportsBeatSecurity = 0;
    private int countDriverReportsBeatSecurity = 0;
    private int countNoticedBySecurity = 0;

    private void doSecurityParkjamCheck() {
        if (!this.hasSecurity) {
            return;
        }

        if (this.nextSecurityCheckTime < 0) {
            this.nextSecurityCheckTime = rand.nextInt(SECURITY_CHECK_INTERVAL);
        }
        if (this.currentTime != this.nextSecurityCheckTime) {
            return;
        }
        this.nextSecurityCheckTime += SECURITY_CHECK_INTERVAL;
        for (CarPark cp : this.carparks) {
            if (cp.isFull()) {
                if (!cp.isParkJamFull()) {
                    cp.setParkjamFull();
                } else if (!this.securityNoticedFull.contains(cp)) {
                    this.totalTimeDriverReportsBeatSecurity += this.currentTime - cp.getTimeOfBecomingFull();
                    this.countDriverReportsBeatSecurity++;
                }
                this.countNoticedBySecurity++;
                this.securityNoticedFull.add(cp);
            }
        }
    }

    private static enum C                                      { ALL, NOPJ, PJ, WEBVIEW, PJFB,   PJF,    PJW,   OPT,   PESS }
    private static String[] typeName = new String[]{ null, "N",   "PJ", "Web",     "PJFB", "PJF", "PJW", "Opt", "Pess" };

    private double[] totalDistanceDriven = new double[C.values().length];
    private int[] totalTimeParking = new int[C.values().length];
    private int[] totalCarsThatFailedParking = new int[C.values().length];
    private int[] totalFailedParkings = new int[C.values().length];
    private int[] maxFailedParkings = new int[C.values().length];
    private int[] countCars = new int[C.values().length];

    private void addStats(C type, Car car) {
        this.totalDistanceDriven[type.ordinal()] += car.getDistanceDriven();
        this.totalTimeParking[type.ordinal()] += car.getTimeSpentParking();
        int failed = car.getFailedParkings();
        if (failed > this.maxFailedParkings[type.ordinal()]) {
            this.maxFailedParkings[type.ordinal()] = failed;
        }
        if (failed > 0) {
            this.totalCarsThatFailedParking[type.ordinal()]++;
            this.totalFailedParkings[type.ordinal()] += failed;
        }
        this.countCars[type.ordinal()]++;
    }

    int totalDriverContributions = 0;

    private int actualPessimists = 0;
    private int actualWebViewCars = 0;
    private int actualParkJamCars = 0;
    private int actualParkJamWCars = 0;
    private int actualParkJamBFCars = 0;
    private int actualParkJamContributingCars = 0;

    private void computeStats() {
        assert this.done : "simulation must run before stats can be computed";

        for (Car car : this.parkedCars) {
            addStats(C.ALL, car);

            addStats(car.pessimistic ? C.PESS : C.OPT, car);
            if (car instanceof ParkJamCarW) {
                addStats(C.PJ, car);
                addStats(C.PJW, car);
            } else if (car instanceof ParkJamCarBF) {
                ParkJamCarBF bfcar = (ParkJamCarBF) car;
                C type;
                if (bfcar.isB) {
                    if (bfcar.isF) {
                        addStats(C.PJ, car);
                        type = C.PJFB;
                    } else {
                        // not counted as PJ car
                        type = C.WEBVIEW;
                    }
                } else {
                    addStats(C.PJ, car);
                    type = C.PJF;
                }
                addStats(type, car);
            } else {
                addStats(C.NOPJ, car);
            }
        }

        assert this.countCars[C.ALL.ordinal()] == this.numberOfCars;
        assert this.countCars[C.PJ.ordinal()] == this.actualParkJamCars;
        assert this.countCars[C.WEBVIEW.ordinal()] == this.actualWebViewCars;
        assert this.countCars[C.PJFB.ordinal()] == this.actualParkJamBFCars;
        assert this.countCars[C.PJF.ordinal()] == (this.actualParkJamCars-this.actualParkJamWCars-this.actualParkJamBFCars);
        assert this.countCars[C.PJW.ordinal()] == this.actualParkJamWCars;
        assert this.countCars[C.OPT.ordinal()] == (this.numberOfCars - this.actualPessimists);
        assert this.countCars[C.PESS.ordinal()] == this.actualPessimists;

//        // sort car parks by when they were full
//        Collections.sort(this.carparks, new Comparator<CarPark>() {
//            @Override
//            public int compare(CarPark cp1, CarPark cp2) {
//                return cp1.getTimeOfBecomingFull() - cp2.getTimeOfBecomingFull();
//            }
//        });
    }

    private static Random rand = new Random();

    private List<Car> generateCars() {
        List<Car> retval = new ArrayList<Car>(this.numberOfCars);

        int totalPreferencePopularities = 0;
        for (Preference pref : this.prefs) {
            totalPreferencePopularities += pref.popularity;
        }

        while (retval.size() < this.numberOfCars) {
            int time; // when the car enters the system
            do {
                time = (int)(rand.nextGaussian()*(DURATION/2/SIGMAS)+DURATION/2);
            } while (time < 0 || time > DURATION);

            int timeLeftHome; // when the car has left home (needed for webview and for FB cars)
            do {
                timeLeftHome = time - (int)(rand.nextGaussian()*AVERAGE_COMMUTE + AVERAGE_COMMUTE); // todo this is v. inaccurate (not normal distribution around t-average_commute, but some other distribution that's bottom-bounded and top-unbounded would be better)
            } while (timeLeftHome > (time-60)); // at least a minute spent going to the campus

            int whichPref = rand.nextInt(totalPreferencePopularities); // where will this car want to go
            Preference pref = null;
            for (Preference candidate : this.prefs) {
                whichPref -= candidate.popularity;
                if (whichPref < 0) {
                    pref = candidate;
                    break;
                }
            }

            int whichEntry = rand.nextInt(100); // where will this car enter the system
            Node entry = (whichEntry < pref.probabilityOfPoint1) ? pref.entryPoint1 : pref.entryPoint2;

            boolean pessimist = rand.nextInt(100) < this.percentPessimists;
            if (pessimist) this.actualPessimists++;

            Car car;
            int type = rand.nextInt(100); // normal parkjam-less, web-view, or park-jam-using
            if (type < this.percentParkJamWebView) {
                car = ParkJamCarBF.createCarB(entry, time, pref.sequence, pessimist, timeLeftHome, this);
                this.actualWebViewCars++;
            } else if (type < this.percentParkJamWebView + this.percentParkJamCars) {
                this.actualParkJamCars++;

                boolean contributing = rand.nextInt(100) < this.percentParkJamContributing;
                if (contributing) this.actualParkJamContributingCars++;

                int subtype = rand.nextInt(100);
                if (subtype < this.percentParkJamW) {
                    car = new ParkJamCarW(entry, time, pref.sequence, pessimist, contributing, this);
                    this.actualParkJamWCars++;
                } else if (rand.nextInt(100) < this.percentParkJamB) {
                    car = ParkJamCarBF.createCarBF(entry, time, pref.sequence, pessimist, timeLeftHome, contributing, this);
                    this.actualParkJamBFCars++;
                } else {
                    car = ParkJamCarBF.createCarF(entry, time, pref.sequence, pessimist, contributing, this);
                }
            } else {
                car = new Car(entry, time, pref.sequence, pessimist, this);
            }

            retval.add(car);
        }
        return retval;
    }

    private void initializeModel() {
        CarPark cp0 = new CarPark(449, "0", 999999, this);   this.carparks.add(cp0);
        CarPark cp1 = new CarPark(112, "1", 9900, this);   this.carparks.add(cp1);
        CarPark cp2 = new CarPark(132, "2", 999999, this);   this.carparks.add(cp2);
        CarPark cp3 = new CarPark(65, "3", 10800, this);   this.carparks.add(cp3);
        CarPark cp4 = new CarPark(55, "4", 12600, this);   this.carparks.add(cp4);
        CarPark cp5 = new CarPark(154, "5", 12600, this);   this.carparks.add(cp5);
        CarPark cp6 = new CarPark(143, "6", 11700, this);   this.carparks.add(cp6);
        CarPark cp7 = new CarPark(247, "7", 999999, this);   this.carparks.add(cp7);
        CarPark cp8 = new CarPark(229, "8", 999999, this);   this.carparks.add(cp8);
        CarPark cp9 = new CarPark(113, "9", 9900, this);   this.carparks.add(cp9);

        // initialize road nodes
        Node nA = new Node(null, "A", this);   this.nodes.add(nA);
        Node nB = new Node(cp0, "B", this);   this.nodes.add(nB);
        Node nC = new Node(cp1, "C", this);   this.nodes.add(nC);
        Node nD = new Node(null, "D", this);   this.nodes.add(nD);
        Node nE = new Node(cp2, "E", this);   this.nodes.add(nE);
        Node nF = new Node(cp3, "F", this);   this.nodes.add(nF);
        Node nG = new Node(cp2, "G", this);   this.nodes.add(nG);
        Node nH = new Node(cp4, "H", this);   this.nodes.add(nH);
        Node nI = new Node(cp5, "I", this);   this.nodes.add(nI);
        Node nJ = new Node(cp7, "J", this);   this.nodes.add(nJ);
        Node nK = new Node(cp6, "K", this);   this.nodes.add(nK);
        Node nL = new Node(cp7, "L", this);   this.nodes.add(nL);
        Node nM = new Node(cp8, "M", this);   this.nodes.add(nM);
        Node nN = new Node(cp9, "N", this);   this.nodes.add(nN);
        Node nO = new Node(null, "O", this);   this.nodes.add(nO);
        Node nP = new Node(null, "P", this);   this.nodes.add(nP);

        // initialize roads between nodes
        Road rAB = new Road(false, nA, nB, 184, "AB", this);    this.roads.add(rAB);
        Road rBA = new Road(false, nB, nA, 184, "BA", this);    this.roads.add(rBA);
        Road rBC = new Road(false, nB, nC, 127, "BC", this);    this.roads.add(rBC);
        Road rCB = new Road(false, nC, nB, 127, "CB", this);    this.roads.add(rCB);
        Road rCD = new Road(false, nC, nD, 30, "CD", this);    this.roads.add(rCD);
        Road rDC = new Road(false, nD, nC, 30, "DC", this);    this.roads.add(rDC);
        Road rDE = new Road(false, nD, nE, 206, "DE", this);    this.roads.add(rDE);
        Road rEF = new Road(false, nE, nF, 56, "EF", this);    this.roads.add(rEF);
        Road rFG = new Road(false, nF, nG, 132, "FG", this);    this.roads.add(rFG);
        Road rGH = new Road(false, nG, nH, 127, "GH", this);    this.roads.add(rGH);
        Road rHI = new Road(false, nH, nI, 33, "HI", this);    this.roads.add(rHI);
//        Road rIH = new Road(false, nI, nH, 33, "IH", this);    this.roads.add(rIH);
        Road rIJ = new Road(false, nI, nJ, 403, "IJ", this);    this.roads.add(rIJ);
        Road rJK = new Road(false, nJ, nK, 48, "JK", this);    this.roads.add(rJK);
        Road rKL = new Road(false, nK, nL, 22, "KL", this);    this.roads.add(rKL);
        Road rLK = new Road(false, nL, nK, 22, "LK", this);    this.roads.add(rLK);
        Road rLM = new Road(false, nL, nM, 46, "LM", this);    this.roads.add(rLM);
        Road rML = new Road(false, nM, nL, 46, "ML", this);    this.roads.add(rML);
        Road rMN = new Road(false, nM, nN, 30, "MN", this);    this.roads.add(rMN);
        Road rNM = new Road(false, nN, nM, 30, "NM", this);    this.roads.add(rNM);
        Road rNO = new Road(false, nN, nO, 85, "NO", this);    this.roads.add(rNO);
        Road rON = new Road(false, nO, nN, 85, "ON", this);    this.roads.add(rON);
        Road rDO = new Road(false, nD, nO, 284, "DO", this);    this.roads.add(rDO);
        Road rOD = new Road(false, nO, nD, 284, "OD", this);    this.roads.add(rOD);
        Road rOP = new Road(false, nO, nP, 156, "OP", this);    this.roads.add(rOP);
        Road rPO = new Road(false, nP, nO, 156, "PO", this);    this.roads.add(rPO);

        // initialize roads that function as delays for cars trying and failing to park in a car park
        Road rBB = new Road(true, nB, nB, 529, "BB", this);        cp0.addRoadInLieuOfFailure(rBB);    this.roads.add(rBB);
        Road rCC = new Road(true, nC, nC, 208, "CC", this);        cp1.addRoadInLieuOfFailure(rCC);    this.roads.add(rCC);
        Road rEG = new Road(true, nE, nG, 224, "EG", this);        cp2.addRoadInLieuOfFailure(rEG);    this.roads.add(rEG);
        Road rGE = new Road(true, nG, nE, 224, "GE", this);        cp2.addRoadInLieuOfFailure(rGE);    this.roads.add(rGE);
        Road rFF = new Road(true, nF, nF, 250, "FF", this);        cp3.addRoadInLieuOfFailure(rFF);    this.roads.add(rFF);
        Road rHH = new Road(true, nH, nH, 165, "HH", this);        cp4.addRoadInLieuOfFailure(rHH);    this.roads.add(rHH);
        Road rII = new Road(true, nI, nI, 301, "II", this);        cp5.addRoadInLieuOfFailure(rII);    this.roads.add(rII);
        Road rKK = new Road(true, nK, nK, 300, "KK", this);        cp6.addRoadInLieuOfFailure(rKK);    this.roads.add(rKK);
        Road rJL = new Road(true, nJ, nL, 331, "JL", this);        cp7.addRoadInLieuOfFailure(rJL);    this.roads.add(rJL);
        Road rLJ = new Road(true, nL, nJ, 331, "LJ", this);        cp7.addRoadInLieuOfFailure(rLJ);    this.roads.add(rLJ);
        Road rMM = new Road(true, nM, nM, 420, "MM", this);        cp8.addRoadInLieuOfFailure(rMM);    this.roads.add(rMM);
        Road rNN = new Road(true, nN, nN, 209, "NN", this);        cp9.addRoadInLieuOfFailure(rNN);    this.roads.add(rNN);

        // initialize routing tables for all the nodes
        nA.addDefaultRoute(rAB);
        nB.addDefaultRoute(rBC);
        nC.addRoute(new CarPark[]{cp0}, rCB);
        nC.addDefaultRoute(rCD);
        nD.addRoute(new CarPark[]{cp0, cp1}, rDC);
        nD.addRoute(new CarPark[]{cp2, cp3, cp4, cp5}, rDE);
        nD.addDefaultRoute(rDO);
        nE.addDefaultRoute(rEF);
        nF.addDefaultRoute(rFG);
        nG.addDefaultRoute(rGH);
        nH.addDefaultRoute(rHI);
//        nI.addRoute(new CarPark[]{cp4}, rIH);
        nI.addDefaultRoute(rIJ);
        nJ.addDefaultRoute(rJK);
        nK.addDefaultRoute(rKL);
        nL.addRoute(new CarPark[]{cp6}, rLK);
        nL.addDefaultRoute(rLM);
        nM.addRoute(new CarPark[]{cp6, cp7}, rML);
        nM.addDefaultRoute(rMN);
        nN.addRoute(new CarPark[]{cp6, cp7, cp8}, rNM);
        nN.addDefaultRoute(rNO);
        nO.addRoute(new CarPark[]{cp6, cp7, cp8, cp9}, rON);
        nO.addDefaultRoute(rOD);
        nP.addDefaultRoute(rPO);

        // initialize a list of possible car preferences for car parks
        this.prefs.add(new Preference(400, new CarPark[]{cp9, cp8, cp7, cp6, cp0, cp1, cp3, cp2, cp4, cp5}, nP, 100, nP));
        this.prefs.add(new Preference(300, new CarPark[]{cp6, cp7, cp8, cp9, cp0, cp1, cp3, cp2, cp4, cp5}, nP, 100, nP));
        this.prefs.add(new Preference(100, new CarPark[]{cp4, cp5, cp6, cp7, cp8, cp9, cp0, cp1, cp3, cp2}, nA,   40, nP));
        this.prefs.add(new Preference(200, new CarPark[]{cp5, cp6, cp7, cp8, cp9, cp0, cp1, cp3, cp2, cp4}, nA,   40, nP));
        this.prefs.add(new Preference(100, new CarPark[]{cp3, cp2, cp4, cp5, cp6, cp7, cp8, cp9, cp0, cp1}, nA,   40, nP));
        this.prefs.add(new Preference(300, new CarPark[]{cp1, cp3, cp2, cp4, cp5, cp6, cp7, cp8, cp9, cp0}, nA,   40, nP));
        this.prefs.add(new Preference(100, new CarPark[]{cp1, cp0, cp9, cp8, cp7, cp6, cp3, cp2, cp4, cp5}, nA,   40, nP));
        this.prefs.add(new Preference(150, new CarPark[]{cp0, cp1, cp3, cp2, cp4, cp5, cp6, cp7, cp8, cp9}, nA,   40, nP));
    }

    private static class Preference {
        CarPark[] sequence;
        int popularity;
        Node entryPoint1, entryPoint2;
        int probabilityOfPoint1;

        Preference(int pop, CarPark[] seq, Node ep1, int pp1, Node ep2) {
            this.popularity = pop;
            this.sequence = seq;
            this.entryPoint1 = ep1;
            this.entryPoint2 = ep2;
            this.probabilityOfPoint1 = pp1;
        }
    }
}
