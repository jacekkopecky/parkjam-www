package uk.ac.open.kmi.parking.simulation;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

class Road extends SimulationElement {
    static final double SPEED_MPH = 15;

    private Node start = null, end = null;
    private int length; // in meters
    private List<CarPosition> cars = new LinkedList<CarPosition>();
    private final double speedmps;

    Road(boolean inLieuOfFailedParking, Node start, Node end, int length, String id, Simulation sim) {
        super(sim);
        double speed = SPEED_MPH*1.609/3.6;
        if (inLieuOfFailedParking) {
            speed /= 2;
        }
        this.speedmps = speed;
        this.start = start;
        this.end = end;
        this.length = length;
        this.id = id;
    }

    private static class CarPosition {
        Car car;
        double position;
    }

    Node getStart() {
        return this.start;
    }

    void addCar(Car car) {
        // put the car at the beginning of this road
        CarPosition newCar = new CarPosition();
        newCar.car = car;
        newCar.position = 0;
        this.cars.add(newCar);
    }

    List<CarPosition> forRemoval = new ArrayList<CarPosition>(20);

    void progress() {
        this.forRemoval.clear();
        for (CarPosition carPosn : this.cars) {
            //    road will update location of car
            //    if done, road will queue a car at the end node, updating its distance traveled
            carPosn.position += this.speedmps;
            if (carPosn.position >= this.length) {
                this.end.addCar(carPosn.car);
                carPosn.car.addTraveled(this.length);
                this.forRemoval.add(carPosn);
            }
        }
        this.cars.removeAll(this.forRemoval);
    }


    private String id;

    @Override
    public String toString() {
        return "Road " + this.id;
    }
}
