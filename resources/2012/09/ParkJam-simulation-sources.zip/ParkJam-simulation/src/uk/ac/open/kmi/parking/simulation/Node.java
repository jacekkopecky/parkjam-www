package uk.ac.open.kmi.parking.simulation;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

class Node extends SimulationElement {
    private CarPark carpark = null;
    private List<Route> routingTable = new LinkedList<Route>();

    private List<Car> queuedCars = new ArrayList<Car>(20);

    Node(CarPark park, String id, Simulation sim) {
        super(sim);
        this.carpark = park;
        this.id = id;
    }

    private void addRoute(CarPark park, Road road) {
        assert !this.addedDefaultRoute : "added a route after default route added";
        Route rt = new Route();
        rt.target = park;
        rt.road = road;
        this.routingTable.add(rt);
    }

    void addRoute(CarPark[] parks, Road road) {
        for (CarPark park : parks) {
            addRoute(park, road);
        }
    }

    private boolean addedDefaultRoute = false;

    void addDefaultRoute(Road road) {
        addRoute((CarPark)null, road);
        this.addedDefaultRoute = true;
    }

    private static class Route {
        CarPark target; // null means catch-all
        Road road;
    }

    void addCar(Car car) {
        this.queuedCars.add(car);
//        System.out.println(car.toString() + " entered " + this);
    }

    void handleWaitingCars() {
        for (Car car : this.queuedCars) {
            car.enteringNewNode();
            CarPark target = car.getCurrentTargetCarpark();
            if (target == this.carpark) {
                //    node can route the car to local car park (if that's the target), from the current node
                target.addCar(car, this);
            } else {
                //    node can route the car to another road where it'll be put at the beginning of it
                findRoute(target).addCar(car);
            }
        }
        this.queuedCars.clear();
    }

    private Road findRoute(CarPark target) {
        for (Route rt : this.routingTable) {
            if (rt.target == null || rt.target == target) {
                return rt.road;
            }
        }
        throw new IllegalStateException("no route found!");
    }

    private String id;

    @Override
    public String toString() {
        return "Node " + this.id;
    }
}