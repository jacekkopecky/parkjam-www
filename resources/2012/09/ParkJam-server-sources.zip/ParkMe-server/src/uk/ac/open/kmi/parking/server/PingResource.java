package uk.ac.open.kmi.parking.server;

import java.util.Date;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.CacheControl;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.openrdf.query.QueryLanguage;

import uk.ac.open.kmi.parking.server.Config.MyRepositoryModel;

/**
 * @author Jacek Kopecky
 * Ping class, should return an uncachable positive text response when the server is alive.
 */
@Path("/ping")
public class PingResource {

    @QueryParam("extra") List<String> extras; // handled values: repostat, geoindex, unverifieds, flush

    private static long nextGeoIndexUpdate = 0;

    /**
     * the minimum delay between subsequent updates of geo index
     */
    private final static long MIN_UPDATE_DELAY = 60000;

    /**
     * @return a positive text response when the server is alive
     */
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public Response ping() {
        String retval = "";
        if (this.extras.contains("repostat")) {
            MyRepositoryModel repomodel = Config.openRepositoryModel(null);
            String query = "ASK { ?s a ?o. }";
            try {
                retval = "repository reachable: " + repomodel.getConnection().prepareBooleanQuery(QueryLanguage.SPARQL, query).evaluate() + "\n";
            } catch (Exception e) {
                e.printStackTrace();
                retval = "reaching repository failed: " + e.getMessage() + "\n";
            } finally {
                Config.closeRepositoryModel(repomodel);
            }
        }
        if (this.extras.contains("flush")) {
            MyRepositoryModel repomodel = Config.openRepositoryModel(null);
            try {
                repomodel.addStatement(Config.OWLIM_flush, Config.OWLIM_flush, Config.OWLIM_flush);
                Config.closeRepositoryModel(repomodel);
                retval = "flush statement added, let's hope it works\n";
            } catch (Exception e) {
                Config.closeRepositoryModel(repomodel);
                e.printStackTrace();
                retval = "reaching repository failed: " + e.getMessage() + "\n";
            }
        }
        if (this.extras.contains("unverifieds")) {
            MyRepositoryModel repomodel = Config.openRepositoryModel(Config.PARKING_MODERATION_CONTEXT);
            String query = "SELECT (COUNT(*) as ?count) where {?x <http://parking.kmi.open.ac.uk/ontologies/parking#hasUnverifiedProperties> ?y.}";
            try {
                retval = "number of unverified bags of properties: " +
                        repomodel.getConnection().prepareTupleQuery(QueryLanguage.SPARQL, query).evaluate().next().getValue("count").stringValue() +
                        "\nModeration console at http://localhost:9090/admin/moderate-props/\n";
            } catch (Exception e) {
                e.printStackTrace();
                retval = "unverifieds query failed: " + e.getMessage() + "\n";
            } finally {
                Config.closeRepositoryModel(repomodel);
            }
        }
        if (this.extras.contains("geoindex")) {
            // tiny race condition in here, multiple threads could at the same time reach the update query, not worth handling
            long currtime = System.currentTimeMillis();
            if (currtime < nextGeoIndexUpdate) {
                retval = "too soon for a geoindex update, wait " + (nextGeoIndexUpdate - currtime)/1000 + " seconds\n";
            } else {
                nextGeoIndexUpdate = currtime + MIN_UPDATE_DELAY;
                MyRepositoryModel repomodel = Config.openRepositoryModel(null);
                String query = "ASK { _:a <http://www.ontotext.com/owlim/geo#createIndex> _:b. }";
                try {
                    retval = "geo index rebuild: " + repomodel.getConnection().prepareBooleanQuery(QueryLanguage.SPARQL, query).evaluate() + "\n";
                    nextGeoIndexUpdate = System.currentTimeMillis() + MIN_UPDATE_DELAY;
                } catch (Exception e) {
                    e.printStackTrace();
                    retval = "geo index update failed: " + e.getMessage() + "\n";
                } finally {
                    Config.closeRepositoryModel(repomodel);
                }
            }
        }
        CacheControl cc = new CacheControl();
        cc.setNoCache(true);
        return Response.ok(retval + "server running " + new Date() + "\n").cacheControl(cc).build();
    }
}
